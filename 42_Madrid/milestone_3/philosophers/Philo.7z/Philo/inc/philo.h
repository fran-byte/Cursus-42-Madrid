/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/27 17:45:07 by frromero          #+#    #+#             */
/*   Updated: 2025/01/29 11:55:59 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILOSOPHERS_H
#define PHILOSOPHERS_H

#include <pthread.h>
#include <limits.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <stdbool.h>

typedef struct	s_philosopher
{
	int	id;
	int	left_fork;
	int	right_fork;
	pthread_t	thread;
	long	last_meal_time;
	int	meal_count;
} t_philosopher;

typedef struct s_simulation
{
	int	num_philosophers;
	int	time_to_die;
	int	time_to_eat;
	int	time_to_sleep;
	int	num_meals;
	int	is_running;
	pthread_mutex_t	*forks;
	t_philosopher	*philosophers;
	pthread_mutex_t	print_mutex;
} t_simulation;

int	atoi_philo(char *str);
size_t	strlen_philo(const char *str);
int	start_simulation(t_simulation *simulation);

#endif
