/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/27 17:28:48 by frromero          #+#    #+#             */
/*   Updated: 2025/01/30 10:35:30 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*• Tu(s) programa(s) debe(n) aceptar los siguientes argumentos:
number_of_philosophers time_to_die time_to_eat time_to_sleep
[number_of_times_each_philosopher_must_eat]*/

#include "../inc/philo.h"

static void error_msg_validate()
{
	printf("\nError. Invalid arguments:  ./philo [#1] [#2] [#3] [#4]\n");
	printf("\n#1: [Number of philosophers]\n#2: [Time to die] (ms)");
	printf("\n#3: [Time to eat] (ms)\n#4: [Time to sleep] (ms)\n\n");
}
static int	parse_arguments(int argc, char **argv)
{
	int	i;
	int	j;

	i = 1;
	while(i < argc)
	{
		j = 0;
		while(argv[i][j] != 0)
		{
			if(!(argv[i][j] >= '0' && argv[i][j] <= '9'))
				{
					error_msg_validate();
					return (1);
				}
			j++;
		}
		i++;
	}
	return (0);
}
static int	validate_arguments(int argc, char **argv, t_simulation *sim)
{
	if (argc != 5 || parse_arguments(argc, argv) != 0)
	{
		error_msg_validate();
		return (1);
	}
	sim->num_philo = atoi_philo(argv[1]);
	sim->time_to_die = atoi_philo(argv[2]);
	sim->time_to_eat = atoi_philo(argv[3]);
	sim->time_to_sleep = atoi_philo(argv[4]);

	if(sim->num_philo <= 0 || sim->time_to_die <= 0
		|| sim->time_to_eat <= 0 || sim->time_to_sleep <= 0)
	{
		error_msg_validate();
		return (1);
	}
	return (0);
}

int	main(int argc, char **argv)
{
	t_simulation *sim;
	long start_time;

	start_time = get_timestamp();
	sim = malloc(sizeof(t_simulation));
	if (!sim)
	{
		printf("\nmalloc Error\n");
		return (1);
	}
	if (validate_arguments(argc, argv, sim) != 0 || start_simulation(sim) != 0)
	{
		free(sim);
		return (1);
	}
	free(sim);
	return (0);
}

