/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/27 17:28:48 by frromero          #+#    #+#             */
/*   Updated: 2025/01/29 13:54:18 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*• Tu(s) programa(s) debe(n) aceptar los siguientes argumentos:
number_of_philosophers time_to_die time_to_eat time_to_sleep
[number_of_times_each_philosopher_must_eat]*/

#include "../inc/philo.h"

static void error_msg_validate()
{
	printf("\nError: Invalid arguments\n\n./philo [#1] [#2] [#3] [#4]\n");
	printf("\n#1: [Number of philosophers]\n#2: [time to die]");
	printf("\n#3: [time to eat]\n#4: [time to sleep]\n\n");
}
static int	parse_arguments(int argc, char **argv)
{
	int	i;
	int	j;

	i = 1;
	while(i < argc)
	{
		j = 0;
		while(argv[i][j] != 0)
		{
			if(!(argv[i][j] >= '0' && argv[i][j] <= '9'))
				{
					error_msg_validate();
					return (1);
				}
			j++;
		}
		i++;
	}
	return (0);
}
static int	validate_arguments(int argc, char **argv, t_simulation *sim)
{
	if (argc != 5 || parse_arguments(argc, argv) != 0)
	{
		error_msg_validate();
		return (1);
	}
	sim->num_philosophers = atoi_philo(argv[1]);
	sim->time_to_die = atoi_philo(argv[2]);
	sim->time_to_eat = atoi_philo(argv[3]);
	sim->time_to_sleep = atoi_philo(argv[4]);
	if(sim->num_philosophers <= 0 || sim->time_to_die <= 0
		|| sim->time_to_eat <= 0 || sim->time_to_sleep <= 0)
	{
		error_msg_validate();
		return (1);
	}

	printf("number_philosophers = %d", sim->num_philosophers);
	return (0);
}

void free_philo(t_simulation *sim, char *str)
{
	printf("%s", str);
	if(sim != NULL)
		free(sim);
}

int	main(int argc, char **argv)
{
	t_simulation *sim;

	sim = NULL;

	if ((validate_arguments(argc, argv, sim) !=  0))
		return (1);
	if(start_simulation(sim) != 0)
	{
		free_philo(sim, "\nError\n");
		return (1);
	}
	free(sim);
	return (0);
}
