/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_start.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/27 23:35:39 by frromero          #+#    #+#             */
/*   Updated: 2025/01/29 13:52:46 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/philo.h"

void *do_philo(void *arg)
{
	t_philosopher *philo;

	philo = (t_philosopher *)arg;

	printf("Filósofo %d ha comenzado\n", philo->id);

	// Aquí iría la lógica del filósofo (pensar, comer, dormir)

	return NULL;
}
int create_philos(t_simulation *sim)
{
	int i;

	i = 1;
	printf("philo: %d", sim->num_philosophers);
	while (i <= sim->num_philosophers)
	{
		// Inicializar los filósofos correctamente
		sim->philosophers[i].id = i;
		sim->philosophers[i].left_fork = i;
		sim->philosophers[i].right_fork = (i + 1) % sim->num_philosophers;

		// Crear el hilo y pasar la estructura del filósofo
		if (pthread_create(&sim->philosophers[i].thread, NULL, do_philo,
			(void *)&sim->philosophers[i]) != 0)
		{
			return (1);
		}
		i++;
	}
}
void	log_state(t_simulation *sim)
{
	;
	// print simulation
}
int start_simulation(t_simulation *sim)
{
	sim->philosophers = malloc(sizeof(t_philosopher) * sim->num_philosophers);
	if (!sim->philosophers)
		return (1);

	if(create_philos(sim) != 0)
		return (1);

	log_state(sim);

}
