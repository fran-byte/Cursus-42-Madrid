/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_start.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/27 23:35:39 by frromero          #+#    #+#             */
/*   Updated: 2025/01/30 13:51:40 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/philo.h"

/* Print the status of a philosopher */
void print_state(t_simulation *sim, int philo_id, char *state)
{
	long timestamp = get_timestamp() - sim->start_time;
	pthread_mutex_lock(&sim->print_mutex);
	if (sim->is_running)
		printf("%ld %d %s\n", timestamp, philo_id, state);
	pthread_mutex_unlock(&sim->print_mutex);
}

/* Monitoring thread: checks for death and self-destructs if it detects a
	dead philosopher*/
void *monitor_deaths(void *arg)
{
	t_simulation *sim = (t_simulation *)arg;

	while (1)
	{
		int i = 0;
		while (i < sim->num_philo)
		{
			long since_last_meal = get_timestamp() - sim->philo[i].last_meal;
			if (since_last_meal >= sim->time_to_die)
			{
				print_state(sim, sim->philo[i].id, "died");
				sim->is_running = 0; // Se detiene la simulación
				return (NULL);		 // El hilo se cierra solo
			}
			i++;
		}
		usleep(2);
	}
}

// Comportamiento del filósofo
void *run_philo(void *arg)
{
	t_philosopher *philo;
	t_simulation *sim;

	philo = (t_philosopher *)arg;
	sim = philo->simulation;
	if (sim->num_philo == 1)
	{
		pthread_mutex_lock(&sim->forks[philo->left_fork]);
		print_state(sim, philo->id, "has taken a fork");
		usleep(sim->time_to_die * 1000);
		print_state(sim, philo->id, "died");
		sim->is_running = 0;
		pthread_mutex_unlock(&sim->forks[philo->left_fork]);
		return (NULL);
	}
	while (sim->is_running)
	{
		if (philo->id % 2 == 0)
		{
			pthread_mutex_lock(&sim->forks[philo->right_fork]);
			print_state(sim, philo->id, "has taken a fork");
			pthread_mutex_lock(&sim->forks[philo->left_fork]);
		}
		else
		{
			pthread_mutex_lock(&sim->forks[philo->left_fork]);
			print_state(sim, philo->id, "has taken a fork");
			pthread_mutex_lock(&sim->forks[philo->right_fork]);
		}
		print_state(sim, philo->id, "has taken a fork");
		print_state(sim, philo->id, "is eating");
		philo->last_meal = get_timestamp();
		usleep(sim->time_to_eat * 1000);

		pthread_mutex_unlock(&sim->forks[philo->left_fork]);
		pthread_mutex_unlock(&sim->forks[philo->right_fork]);

		print_state(sim, philo->id, "is sleeping");
		usleep(sim->time_to_sleep * 1000);

		print_state(sim, philo->id, "is thinking");
	}
	return (NULL);
}

/*  Create the threads of the philosophers */
int create_philos(t_simulation *sim)
{
	int i = 0;
	while (i < sim->num_philo)
	{
		sim->philo[i].id = i + 1;
		sim->philo[i].left_fork = i;
		sim->philo[i].right_fork = (i + 1) % sim->num_philo;
		sim->philo[i].simulation = sim;
		sim->philo[i].last_meal = get_timestamp();

		if (pthread_create(&sim->philo[i].thread, NULL, run_philo,
			(void *)&sim->philo[i]) != 0)
		{
			printf("Error: No se pudo crear el hilo del filósofo %d\n", i + 1);
			return (1);
		}
		i++;
	}
	return (0);
}

/*  Start the simulation */
int start_simulation(t_simulation *sim)
{
	int i;

	i = 0;
	sim->start_time = get_timestamp();
	sim->philo = malloc(sizeof(t_philosopher) * sim->num_philo);
	if (!sim->philo)
		return (1);
	sim->forks = malloc(sizeof(pthread_mutex_t) * sim->num_philo);
	if (!sim->forks)
		return (1);
	while (i < sim->num_philo)
	{
		pthread_mutex_init(&sim->forks[i], NULL);
		i++;
	}
	pthread_mutex_init(&sim->print_mutex, NULL);
	sim->is_running = 1;
	// Crear el hilo de monitoreo (se autocontrola y termina solo si alguien muere)
	if (pthread_create(&sim->monitor_thread, NULL, monitor_deaths, (void *)sim) != 0)
	{
		printf("Error: No se pudo crear el hilo de monitoreo\n");
		return (1);
	}
	// Crear los hilos de los filósofos
	if (create_philos(sim) != 0)
		return (1);
	// Esperar a que los filósofos terminen
	i = 0;
	while (i < sim->num_philo)
	{
		pthread_join(sim->philo[i].thread, NULL);
		i++;
	}
	// Esperar al hilo de monitoreo (se cierra solo si alguien muere)
	pthread_join(sim->monitor_thread, NULL);
	return (0);
}

/* - `./philo 1 800 200 200` => one death at 800 ms
- `./philo 3 500 200 400` => one death at 500 ms
- `./philo 5 800 200 200` => infinite
- `./philo 4 310 200 100` => one death at 310 ms
- `./philo 4 410 200 200` => infinite
- `./philo 4 200 210 200` => one death at 200 ms
- `./philo 4 311 150 150` => infinite
- `./philo 4 311 150 162` => one death at 462 ms or more

- `./philo x 100 50 50`
if x mod 2 == 0
=> infinite
else
=> one death at 100ms */
