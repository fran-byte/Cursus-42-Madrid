/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_monitor_deaths.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/30 23:35:35 by frromero          #+#    #+#             */
/*   Updated: 2025/01/31 01:08:35 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/philo.h"

/*
 * @brief Monitors the philosophers to check if any have died.
 * @param arg Pointer to the simulation structure (cast to void*).
 * @return NULL when the simulation ends or a philosopher dies.
 */
void	*monitor_deaths(void *arg)
{
	t_simulation	*sim;
	long			since_last_meal;
	int				i;

	sim = (t_simulation *)arg;
	while (sim->is_running)
	{
		i = 0;
		while (i < sim->num_philo)
		{
			pthread_mutex_lock(&sim->state_mutex);
			since_last_meal = get_timestamp() - sim->phil[i].last_meal;
			pthread_mutex_unlock(&sim->state_mutex);
			if (since_last_meal >= sim->time_to_die)
			{
				print_state(sim, sim->phil[i].id, "died");
				pthread_mutex_lock(&sim->state_mutex);
				sim->is_running = 0;
				pthread_mutex_unlock(&sim->state_mutex);
				return (NULL);
			}
			i++;
		}
	}
	return (NULL);
}
