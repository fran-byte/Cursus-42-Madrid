/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/27 17:28:48 by frromero          #+#    #+#             */
/*   Updated: 2025/01/27 23:41:05 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*• Tu(s) programa(s) debe(n) aceptar los siguientes argumentos:
number_of_philosophers time_to_die time_to_eat time_to_sleep
[number_of_times_each_philosopher_must_eat]*/

#include "../inc/philo.h"

static void error_msg()
{
	printf("\nError: Invalid arguments\n\n./philo [#1] [#2] [#3] [#4]\n");
	printf("\n#1: [Number of philosophers]\n#2: [time to die]");
	printf("\n#3: [time to eat]\n#4: [time to sleep]\n\n");
}
static int	parse_arguments(int argc, char **argv)
{
	int	i;
	int	j;

	i = 1;
	while(i < argc)
	{
		j = 0;
		while(argv[i][j] != 0)
		{
			if(!(argv[i][j] >= '0' && argv[i][j] <= '9'))
				{
					error_msg();
					return (1);
				}
			j++;
		}
		i++;
	}
	return (0);
}
static int	validate_arguments(int argc, char **argv, t_slap *slap)
{
	if (argc != 5 || parse_arguments(argc, argv) != 0)
	{
		error_msg();
		return (1);
	}
	slap->number_philosophers = atoi_philo(argv[1]);
	slap->time_to_die = atoi_philo(argv[2]);
	slap->time_to_eat = atoi_philo(argv[3]);
	slap->time_to_sleep = atoi_philo(argv[4]);
	if(slap->number_philosophers <= 0 || slap->time_to_die <= 0
		|| slap->time_to_eat <= 0 || slap->time_to_sleep <= 0)
	{
		error_msg();
		return (1);
	}

	printf("number_philosophers = %d", slap->number_philosophers);
	return (0);
}

int	main(int argc, char **argv)
{
	t_slap *slap;

	slap = malloc(sizeof(t_slap));
	if (!slap)
	{
		printf("Error\nMalloc Error");
		return (1);
	}
	if ((validate_arguments(argc, argv, slap) !=  0))
		return (1);
	philo_start(slap);
	free(slap);
	return (0);
}
