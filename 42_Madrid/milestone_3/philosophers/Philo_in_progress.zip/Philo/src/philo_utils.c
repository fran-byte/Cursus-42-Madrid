/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/27 21:07:27 by frromero          #+#    #+#             */
/*   Updated: 2025/01/27 23:06:53 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/philo.h"

int	atoi_philo(char *str)
{
	int	result;
	int	sign;

	result = 0;
	sign = 1;
	while (*str == ' ' || *str == '\t' || *str == '\n' || *str == '\v'
		|| *str == '\f' || *str == '\r')
		str++;
	if ((*str == '+' || *str == '-') && (*(str + 1) == '+'
			|| *(str + 1) == '-'))
		return (0);
	if (*str == '+')
		str++;
	else if (*str == '-')
	{
		sign = -1 * sign;
		str++;
	}
	while (*str >= '0' && *str <= '9')
	{
		result = 10 * result + *str - '0';
		str++;
	}
	return (sign * result);
}


size_t	strlen_philo(const char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}
