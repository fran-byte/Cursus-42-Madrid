/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/27 17:45:07 by frromero          #+#    #+#             */
/*   Updated: 2025/01/27 23:39:16 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILOSOPHERS_H
# define PHILOSOPHERS_H

# include <pthread.h>
# include <limits.h>
# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>
# include <sys/time.h>
# include <stdbool.h>

typedef struct s_slap
{

	int		number_philosophers;
	int				time_to_die;
	int				time_to_eat;
	int				time_to_sleep;
}	t_slap;


int	atoi_philo(char *str);
size_t	strlen_philo(const char *str);
void	philo_start(t_slap *slap);



#endif
