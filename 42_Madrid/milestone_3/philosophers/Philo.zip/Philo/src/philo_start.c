/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_start.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/27 23:35:39 by frromero          #+#    #+#             */
/*   Updated: 2025/01/29 21:16:09 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/philo.h"

void print_state(t_simulation *sim, int philo_id, char *state)
{
    long timestamp = get_timestamp() - sim->start_time;
    pthread_mutex_lock(&sim->print_mutex);
    if (sim->is_running)
        printf("%ld %d %s\n", timestamp, philo_id, state);
    pthread_mutex_unlock(&sim->print_mutex);
}

// Verifica si un filósofo ha muerto
void check_death(t_philosopher *philo, t_simulation *sim)
{
    long time_since_last_meal = get_timestamp() - philo->last_meal_time;
    if (time_since_last_meal >= sim->time_to_die)
    {
        print_state(sim, philo->id, "died");
        sim->is_running = 0; // Detener la simulación
    }
}

// Comportamiento del filósofo
void *do_philo(void *arg)
{
    t_philosopher *philo = (t_philosopher *)arg;
    t_simulation *sim = philo->simulation;

    // Caso especial: Si hay solo un filósofo, muere esperando el segundo tenedor
    if (sim->num_philosophers == 1)
    {
        pthread_mutex_lock(&sim->forks[philo->left_fork]);
        print_state(sim, philo->id, "has taken a fork");
        usleep(sim->time_to_die * 1000); // Espera hasta morir
        print_state(sim, philo->id, "died");
        sim->is_running = 0;
        pthread_mutex_unlock(&sim->forks[philo->left_fork]);
        return NULL;
    }

    while (sim->is_running)
    {
        check_death(philo, sim);
        if (!sim->is_running) return NULL;

        // Tomar los tenedores con estrategia de menor índice primero
        if (philo->id % 2 == 0)
        {
            pthread_mutex_lock(&sim->forks[philo->right_fork]);
            print_state(sim, philo->id, "has taken a fork");
            pthread_mutex_lock(&sim->forks[philo->left_fork]);
        }
        else
        {
            pthread_mutex_lock(&sim->forks[philo->left_fork]);
            print_state(sim, philo->id, "has taken a fork");
            pthread_mutex_lock(&sim->forks[philo->right_fork]);
        }

        print_state(sim, philo->id, "has taken a fork");
        print_state(sim, philo->id, "is eating");
        philo->last_meal_time = get_timestamp();
        usleep(sim->time_to_eat * 1000);

        // Soltar los tenedores
        pthread_mutex_unlock(&sim->forks[philo->left_fork]);
        pthread_mutex_unlock(&sim->forks[philo->right_fork]);

        print_state(sim, philo->id, "is sleeping");
        usleep(sim->time_to_sleep * 1000);

        print_state(sim, philo->id, "is thinking");
    }
    return NULL;
}

// Crea los hilos de los filósofos
int create_philos(t_simulation *sim)
{
    int i = 0;
    while (i < sim->num_philosophers)
    {
        sim->philosophers[i].id = i + 1;
        sim->philosophers[i].left_fork = i;
        sim->philosophers[i].right_fork = (i + 1) % sim->num_philosophers;
        sim->philosophers[i].simulation = sim;
        sim->philosophers[i].last_meal_time = sim->start_time;

        if (pthread_create(&sim->philosophers[i].thread, NULL, do_philo,
                           (void *)&sim->philosophers[i]) != 0)
        {
            printf("Error: Failed to create philosopher thread %d\n", i + 1);
            while (--i >= 0)
                pthread_detach(sim->philosophers[i].thread);
            return (1);
        }
        i++;
    }

    i = 0;
    while (i < sim->num_philosophers)
    {
        pthread_join(sim->philosophers[i].thread, NULL);
        i++;
    }
    return (0);
}

// Inicia la simulación
int start_simulation(t_simulation *sim)
{
    sim->start_time = get_timestamp();

    sim->philosophers = malloc(sizeof(t_philosopher) * sim->num_philosophers);
    if (!sim->philosophers) return (1);

    sim->forks = malloc(sizeof(pthread_mutex_t) * sim->num_philosophers);
    if (!sim->forks) return (1);

    int i = 0;
    while (i < sim->num_philosophers)
    {
        if (pthread_mutex_init(&sim->forks[i], NULL) != 0)
        {
            printf("Error initializing mutex for fork %d\n", i);
            return (1);
        }
        i++;
    }

    if (pthread_mutex_init(&sim->print_mutex, NULL) != 0)
        return (1);

    sim->is_running = 1;

    if (create_philos(sim) != 0)
        return (1);

    return (0);
}


/* - `./philo 1 800 200 200`	=> one death at 800 ms
- `./philo 3 500 200 400`	=> one death at 500 ms
- `./philo 5 800 200 200`	=> infinite
- `./philo 4 310 200 100`	=> one death at 310 ms
- `./philo 4 410 200 200`	=> infinite
- `./philo 4 200 210 200`	=> one death at 200 ms
- `./philo 4 311 150 150`	=> infinite
- `./philo 4 311 150 162`	=> one death at 462 ms or more

- `./philo x 100 50 50`
if x mod 2 == 0
	=> infinite
else
	=> one death at 100ms */
