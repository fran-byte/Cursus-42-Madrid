/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_env_path_utils.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/08 23:57:27 by frromero          #+#    #+#             */
/*   Updated: 2025/02/21 08:03:48 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"


/**
 * @brief Creates a new environment node from a directory.
 * Allocates memory for the node and stores the directory value.
 */
t_enviroment *create_env_node(char *directory)
{
	t_enviroment *env_node;

	if (!directory)
		return (NULL);
	env_node = (t_enviroment *)malloc(sizeof(t_enviroment));
	if (!env_node)
		return (NULL);
	env_node->value = ft_strdup(directory);
	if (!env_node->value)
	{
		free(env_node);
		return (NULL);
	}
	env_node->next = NULL;
	return (env_node);
}

/**
 * @brief Adds a new environment node to the end of the list.
 * If the list is empty, the new node becomes the first node.
 */
void add_env_node_to_list(t_enviroment **list, t_enviroment *new_node)
{
	t_enviroment *temp;

	if (!list || !new_node)
		return ;
	if (!*list)
	{
		*list = new_node;
		return ;
	}
	temp = *list;
	while (temp->next)
		temp = temp->next;
	temp->next = new_node;
}
