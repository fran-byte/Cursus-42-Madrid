/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_env.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/14 19:33:55 by frromero          #+#    #+#             */
/*   Updated: 2025/02/16 21:39:24 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Converts environment variables array to linked list
 * @param envp Null-terminated array of environment variable strings
 * @return t_enviroment* Head of environment list, NULL on allocation failure
 * @note Frees envp array if node creation fails
 */
t_enviroment *store_env(char **envp)
{
	int i;
	t_enviroment *env_node;
	t_enviroment *env_list;

	i = 0;
	env_list = NULL;
	while (envp[i])
	{
		env_node = create_env_node(envp[i]);
		if (!env_node)
			return (ft_free_tab(envp), NULL);
		add_env_node_to_list(&env_list, env_node);
		i++;
	}
	return (env_list);
}

