#include "../../inc/minishell.h"

void free_env_array(char **env_array)
{
	int i = 0;
	while (env_array[i])
	{
		free(env_array[i]);
		i++;
	}
	free(env_array);
}

char **convert_env_list_to_array(t_enviroment *env)
{
	int count = 0;
	t_enviroment *current = env;
	while (current)
	{
		count++;
		current = current->next;
	}

	char **env_array = malloc((count + 1) * sizeof(char *));
	if (!env_array)
	{
		perror("malloc");
		return NULL;
	}

	current = env;
	int i = 0;
	while (i < count)
	{
		env_array[i] = strdup(current->value);
		if (!env_array[i])
		{
			perror("strdup");
			while (i > 0)
				free(env_array[--i]);
			free(env_array);
			return NULL;
		}
		current = current->next;
		i++;
	}
	env_array[count] = NULL;
	return env_array;
}
