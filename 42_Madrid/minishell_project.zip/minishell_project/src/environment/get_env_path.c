/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_env_path.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/08 15:09:43 by frromero          #+#    #+#             */
/*   Updated: 2025/02/19 19:58:04 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Locates PATH variable in environment array
 * @param envp Environment variables array
 * @return char* PATH value after "PATH=", NULL if not found
 */
static char *find_path_env(char **envp)
{
	while (*envp)
	{
		if (ft_strnstr(*envp, "PATH=", 5))
			return (*envp + 5);
		envp++;
	}
	return (NULL);
}

/**
 * @brief Splits PATH string into directory components
 * @param path_env PATH environment variable value
 * @return char** Null-terminated array of directory paths
 */
static char **get_directories_from_path(char *path_env)
{
	if (!path_env)
		return (NULL);
	return (ft_split(path_env, ':'));
}

/**
 * @brief Creates linked list from PATH environment variable
 * @param envp Environment variables array
 * @return t_enviroment* Head of PATH directory list, NULL on failure
 * @note Frees temporary directory array before returning
 */
t_enviroment *store_path(char **envp)
{
	char *path_env;
	char **directories;
	t_enviroment *path_list;
	t_enviroment *env_node;
	int i;

	i = 0;
	path_env = find_path_env(envp);
	if (!path_env)
		return (NULL);
	directories = get_directories_from_path(path_env);
	if (!directories)
		return (NULL);
	path_list = NULL;
	while (directories[i])
	{
		env_node = create_env_node(directories[i]);
		if (!env_node)
			return (ft_free_tab(directories), NULL);
		add_env_node_to_list(&path_list, env_node);
		i++;
	}
	return (ft_free_tab(directories), path_list);
}
