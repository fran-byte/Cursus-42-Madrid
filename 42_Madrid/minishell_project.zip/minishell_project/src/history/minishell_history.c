/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell_history.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/08 10:45:07 by frromero          #+#    #+#             */
/*   Updated: 2025/02/19 19:56:30 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"
#define MAX_HISTORY_SIZE 1500
#define REMOVE_HISTORY_SIZE 1000



/**
 * @brief Maintains history size by trimming oldest entries when limit exceeded
 * @param shell Shell context containing history tracking data
 * @details Removes REMOVE_HISTORY_SIZE entries when exceeding MAX_HISTORY_SIZE
 */
static void control_history(t_shell *shell)
{
	int i;

	i = 0;
	if (shell->history_count > MAX_HISTORY_SIZE)
	{
		while (i < REMOVE_HISTORY_SIZE)
		{
			remove_history(0);
			i++;
		}
		shell->history_count = 0;
	}
}

/**
 * @brief Updates shell history with current input and persists to file
 * @param shell Shell context containing history and input data
 * @note Handles empty inputs and maintains history size constraints
 */
void update_history(t_shell *shell)
{
	add_history(shell->input_user);
	write_history(HISTORY_FILE);
	control_history(shell);
}

/**
 * @brief Loads command history from a file.
 * Reads each line and adds it to readline history.
 * Uses get_next_line for reading.
 */
static void load_history_from_file(void)
{
	char *line;
	size_t len;
	int fd;

	fd = open(HISTORY_FILE, O_RDONLY);
	if (fd == -1)
	{
		perror("<-- Error opening history file");
		return;
	}
	line = get_next_line(fd);
	while (line != NULL)
	{
		len = ft_strlen(line);
		if (len > 0 && line[len - 1] == '\n')
			line[len - 1] = '\0';
		add_history(line);
		free(line);
		line = get_next_line(fd);
	}
	close(fd);
	printf("--> History file loaded successfully.\n");
}

/**
 * @brief Creates the history file if it does not exist.
 * Loads history from the file if available.
 */
void create_history_file(void)
{
	int fd;

	fd = open(HISTORY_FILE, O_WRONLY | O_CREAT, 0644);
	if (fd == -1)
		printf("--> Could not create history file. It may already exist.\n");
	else
	{
		printf("--> History file created successfully.\n");
		close(fd);
	}
	if (access(HISTORY_FILE, F_OK) != -1)
		load_history_from_file();
	else
		printf("--> No history file found, starting a new history.\n");
}
