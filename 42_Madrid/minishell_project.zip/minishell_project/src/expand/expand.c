/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expand.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/22 14:02:58 by frromero          #+#    #+#             */
/*   Updated: 2025/02/22 21:34:34 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

static int handle_remainder(t_shell *sh, char *tk, int *i, t_expand *exp)
{
	expand_var_or_dollar(sh, tk, i, exp);
	return (0);
}
static int count_dollars(char *token, int *i)
{
	int count;

	count = 0;
	while (token[*i + count] == DOLLAR)
		count++;
	*i += count;
	return (count);
}
static void handle_pairs(t_expand *exp, int pairs)
{
	size_t old_size;

	old_size = exp->size;
	while (pairs--)
	{
		if (exp->j + 2 >= (int)exp->size)
		{
			exp->size = exp->j + 3;
			exp->result = ft_realloc(exp->result, old_size, exp->size);
			old_size = exp->size;
		}
		exp->result[exp->j++] = DOLLAR;
		exp->result[exp->j++] = DOLLAR;
	}
}

static char *process_dollars(t_shell *sh, char *tk)
{
	t_expand exp;
	int i;
	int d_cnt;

	i = 0;
	exp.j = 0;
	exp.size = ft_strlen(tk) * 2 + 1;
	exp.result = ft_calloc(exp.size, 1);
	while (exp.result && tk[i])
	{
		if (tk[i] == DOLLAR)
		{
			d_cnt = count_dollars(tk, &i);
			handle_pairs(&exp, d_cnt / 2);
			if (d_cnt % 2 != 0 && handle_remainder(sh, tk, &i, &exp))
				break;
		}
		else
			add_normal_char(&exp, tk[i++]);
	}
	if (exp.result)
		exp.result[exp.j] = '\0';
	return (exp.result);
}

void expand(t_shell *shell)
{
	t_token *tmp;

	tmp = shell->tokens;
	while (tmp)
	{
		if (tmp->type == WORD && ft_strchr(tmp->value, DOLLAR))
			tmp->value = process_dollars(shell, tmp->value);
		tmp = tmp->next;
	}
}
