/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expand_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/22 21:13:03 by frromero          #+#    #+#             */
/*   Updated: 2025/02/22 21:34:29 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"



char *extract_var_name(char *token, int *i)
{
	int var_len;
	char *var_name;

	var_len = 0;
	while (token[*i + var_len] && (ft_isalnum(token[*i + var_len])
		|| token[*i + var_len] == '_'))
		var_len++;
	var_name = malloc(var_len + 1);
	if (!var_name)
		return (NULL);
	ft_strlcpy(var_name, &token[*i], var_len + 1);
	*i += var_len;
	return (var_name);
}

void expand_env_value(t_expand *exp, char *exp_val)
{
	size_t exp_len;
	size_t old_size;

	exp_len = 0;
	if (exp_val)
		exp_len = ft_strlen(exp_val);
	old_size = exp->size;
	if (exp->j + exp_len >= exp->size)
	{
		exp->size = exp->j + exp_len + 1;
		exp->result = ft_realloc(exp->result, old_size, exp->size);
	}
	if (exp_val)
		ft_strlcpy(&exp->result[exp->j], exp_val, exp_len + 1);
	exp->j += exp_len;
}

void expand_var_or_dollar(t_shell *sh, char *tk, int *i, t_expand *exp)
{
	char *var_name;
	char *exp_val;

	if (tk[*i] == '?' || ft_isalpha(tk[*i]) || tk[*i] == '_')
	{
		var_name = extract_var_name(tk, i);
		if (!var_name)
			return;
		exp_val = get_env_var(sh, var_name);
		expand_env_value(exp, exp_val);
		free(var_name);
	}
	else
	{
		if (exp->j + 1 >= (int)exp->size)
		{
			exp->size = exp->j + 2;
			exp->result = ft_realloc(exp->result, exp->size - 2, exp->size);
		}
		exp->result[exp->j++] = DOLLAR;
	}
}

void add_normal_char(t_expand *exp, char c)
{
	size_t old_size;

	old_size = exp->size;
	if (exp->j + 1 >= (int)exp->size)
	{
		exp->size = exp->j + 2;
		exp->result = ft_realloc(exp->result, old_size, exp->size);
	}
	exp->result[exp->j++] = c;
}
