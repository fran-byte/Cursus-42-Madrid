#include "../../inc/minishell.h"

char *read_heredoc(const char *delimiter)
{
    char *line = NULL;
    char *heredoc_content = NULL;
    size_t heredoc_len = 0;
    size_t line_len;

    while (1)
    {
        line = readline("heredoc> ");
        if (!line)
            break;
        if (ft_strcmp(line, delimiter) == 0)
        {
            free(line);
            break;
        }
        line_len = ft_strlen(line);
        heredoc_content = ft_realloc(heredoc_content, heredoc_len, heredoc_len + line_len + 2);
        if (!heredoc_content)
        {
            perror("ft_realloc");
            free(line);
            return NULL;
        }
        strcpy(heredoc_content + heredoc_len, line);
        heredoc_len += line_len;
        heredoc_content[heredoc_len] = '\n';
        heredoc_len++;
        heredoc_content[heredoc_len] = '\0';
        free(line);
    }
    return heredoc_content;
}