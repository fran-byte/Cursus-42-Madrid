#include "../../inc/minishell.h"

static char *find_path_env(t_enviroment *envp)
{
    while (envp)
    {
        if (ft_strnstr(envp->value, "PATH=", 5))
            return (envp->value + 5);
        envp = envp->next;
    }
    return (NULL);
}

static char *construct_cmd_path(char *directory, char *cmd)
{
    char *full_path;
    char *command_path;

    full_path = ft_strjoin(directory, "/");
    if (!full_path)
        return (NULL);
    command_path = ft_strjoin(full_path, cmd);
    free(full_path);
    if (!command_path)
        return (NULL);
    if (access(command_path, X_OK) == 0)
        return (command_path);
    free(command_path);
    return (NULL);
}

char *get_path(char *cmd, t_enviroment *env)
{
    char *path_env;
    char **directories;
    char *command_path;
    int i;

    path_env = find_path_env(env);
    if (!path_env)
        return (NULL);
    directories = ft_split(path_env, ':');
    if (!directories)
        return (NULL);
    i = 0;
    while (directories[i])
    {
        command_path = construct_cmd_path(directories[i], cmd);
        if (command_path)
        {
            ft_free_tab(directories);
            return (command_path);
        }
        i++;
    }
    ft_free_tab(directories);
    return (NULL);
}