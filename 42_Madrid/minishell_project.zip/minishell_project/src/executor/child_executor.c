#include "../../inc/minishell.h"

// void exe_children(t_command *current_cmd, int pipe_fd[2], int prev_fd)
// {
//     if (current_cmd->input_fd != STDIN_FILENO)
//     {
//         dup2(current_cmd->input_fd, STDIN_FILENO);
//         close(current_cmd->input_fd);
//     }
//     if (current_cmd->output_fd != STDOUT_FILENO)
//     {
//         dup2(current_cmd->output_fd, STDOUT_FILENO);
//         close(current_cmd->output_fd);
//     }
//     if (prev_fd != -1)
//     {
//         dup2(prev_fd, STDIN_FILENO);
//         close(prev_fd);
//     }
//     if (current_cmd->next)
//     {
//         dup2(pipe_fd[1], STDOUT_FILENO);
//         close(pipe_fd[1]);
//     }
//     if (current_cmd->heredoc_content)
//     {
//         int heredoc_pipe[2];
//         pipe(heredoc_pipe);
//         write(heredoc_pipe[1], current_cmd->heredoc_content, strlen(current_cmd->heredoc_content));
//         close(heredoc_pipe[1]);
//         dup2(heredoc_pipe[0], STDIN_FILENO);
//         close(heredoc_pipe[0]);
//     }
//     execvp(current_cmd->args[0], current_cmd->args);
//     perror("execvp");
//     exit(EXIT_FAILURE);
// }

void exe_children(t_command *current_cmd, int pipe_fd[2], int prev_fd, t_enviroment *env)
{
    if (prev_fd != -1)
    {
        dup2(prev_fd, STDIN_FILENO);
        close(prev_fd);
    }
    if (current_cmd->next)
    {
        dup2(pipe_fd[1], STDOUT_FILENO);
        close(pipe_fd[1]);
        close(pipe_fd[0]);
    }
    if (current_cmd->input_fd != STDIN_FILENO)
    {
        dup2(current_cmd->input_fd, STDIN_FILENO);
        close(current_cmd->input_fd);
    }
    if (current_cmd->output_fd != STDOUT_FILENO)
    {
        dup2(current_cmd->output_fd, STDOUT_FILENO);
        close(current_cmd->output_fd);
    }
    if (current_cmd->heredoc_content)
    {
        int heredoc_pipe[2];
        pipe(heredoc_pipe);
        write(heredoc_pipe[1], current_cmd->heredoc_content, ft_strlen(current_cmd->heredoc_content));
        close(heredoc_pipe[1]);
        dup2(heredoc_pipe[0], STDIN_FILENO);
        close(heredoc_pipe[0]);
    }
    char *cmd_path = get_path(current_cmd->args[0], env);
    if (!cmd_path)
    {
        write(STDERR_FILENO, "Command not found: ", 19);
        write(STDERR_FILENO, current_cmd->args[0], strlen(current_cmd->args[0]));
        write(STDERR_FILENO, "\n", 1);
        exit(127);
    }
    execve(cmd_path, current_cmd->args, convert_env_list_to_array(env));
    perror("execve");
    free(cmd_path);
    exit(EXIT_FAILURE);
}