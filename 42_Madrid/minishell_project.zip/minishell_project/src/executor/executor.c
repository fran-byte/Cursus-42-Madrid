/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   executor.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/14 00:44:43 by user              #+#    #+#             */
/*   Updated: 2025/02/23 20:00:27 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

// t_command *create_command(char **args, int input_fd, int output_fd, int append, char *heredoc_content)
// {
//     t_command *cmd = (t_command *)malloc(sizeof(t_command));
//     if (!cmd)
//         return (NULL);
//     cmd->args = args;
//     cmd->input_fd = input_fd;
//     cmd->output_fd = output_fd;
//     cmd->append = append;
//     cmd->heredoc_content = heredoc_content;
//     cmd->next = NULL;
//     return (cmd);
// }

t_command *create_cmd_node(t_token *token)
{
	t_command *cmd;

	cmd = (t_command *)malloc(sizeof(t_command));
	if (!cmd)
		return (NULL);
	cmd->args = NULL;
	cmd->input_fd = STDIN_FILENO;
	cmd->output_fd = STDOUT_FILENO;
	cmd->append = 0;
	cmd->heredoc_content = NULL;
	cmd->next = NULL;
	return (cmd);
}

void execute_commands(t_command *cmd_list, t_enviroment *env)
{
	t_command *current_cmd = cmd_list;
	int pipe_fd[2];
	int prev_fd = -1;
	int status;


	while (current_cmd)
	{
		if (current_cmd->next)
			pipe(pipe_fd);
		pid_t pid = fork();
		if (pid == -1)
		{
			perror("fork");
			exit(EXIT_FAILURE);
		}
		if (pid == 0)
		{
			exe_children(current_cmd, pipe_fd, prev_fd, env);
		}
		else if (pid > 0)
		{
			if (prev_fd != -1)
				close(prev_fd);
			if (current_cmd->next)
			{
				close(pipe_fd[1]);
				prev_fd = pipe_fd[0];
			}
			waitpid(pid, &status, 0);
		}
		current_cmd = current_cmd->next;
	}
}

/* int main(void)
{
	// Comando 1: ls -l
	char *args1[] = {"ls", "-l", NULL};
	t_command *cmd1 = create_command(args1, STDIN_FILENO, STDOUT_FILENO, 0);

	// Comando 2: grep minishell
	char *args2[] = {"grep", "minishell", NULL};
	t_command *cmd2 = create_command(args2, STDIN_FILENO, STDOUT_FILENO, 0);

	// Comando 3: wc -l
	char *args3[] = {"wc", "-l", NULL};
	t_command *cmd3 = create_command(args3, STDIN_FILENO, STDOUT_FILENO, 0);

	// Configurar pipes
	cmd1->next = cmd2;
	cmd2->next = cmd3;

	// Ejecutar comandos
	execute_commands(cmd1);

	// Liberar memoria
	free(cmd1);
	free(cmd2);
	free(cmd3);

	return 0;
}
 */

/* int main(void)
{
	// Comando 1: cat input.txt
	char *args1[] = {"cat", NULL};
	int input_fd = open("input.txt", O_RDONLY);
	t_command *cmd1 = create_command(args1, input_fd, STDOUT_FILENO, 0);

	// Comando 2: grep minishell
	char *args2[] = {"grep", "minishell", NULL};
	t_command *cmd2 = create_command(args2, STDIN_FILENO, STDOUT_FILENO, 0);

	// Comando 3: wc -l > output.txt
	char *args3[] = {"wc", "-l", NULL};
	int output_fd = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
	t_command *cmd3 = create_command(args3, STDIN_FILENO, output_fd, 1);

	// Configurar pipes
	cmd1->next = cmd2;
	cmd2->next = cmd3;

	// Ejecutar comandos
	execute_commands(cmd1);

	// Liberar memoria
	close(input_fd);
	close(output_fd);
	free(cmd1);
	free(cmd2);
	free(cmd3);

	return 0;
} */

/* int main(void)
{
	// Comando 1: cat input.txt
	char *args1[] = {"cat", NULL};
	int input_fd = open("input.txt", O_RDONLY);
	t_command *cmd1 = create_command(args1, input_fd, STDOUT_FILENO, 0, NULL);

	// Comando 2: grep minishell
	char *args2[] = {"grep", "minishell", NULL};
	t_command *cmd2 = create_command(args2, STDIN_FILENO, STDOUT_FILENO, 0, NULL);

	// Comando 3: wc -l >> output.txt (append)
	char *args3[] = {"wc", "-l", NULL};
	int output_fd = open("output.txt", O_WRONLY | O_CREAT | O_APPEND, 0644);
	t_command *cmd3 = create_command(args3, STDIN_FILENO, output_fd, 1, NULL);

	// Comando 4: heredoc
	char *args4[] = {"cat", NULL};
	char *heredoc_content = read_heredoc("echo");
	int output_fd = open("output.txt", O_WRONLY | O_CREAT | O_APPEND, 0644);
	t_command *cmd4 = create_command(args4, STDIN_FILENO, output_fd, 0, heredoc_content);

	// Configurar pipes
	cmd1->next = cmd2;
	cmd2->next = cmd3;
	cmd3->next = cmd4;

	// Ejecutar comandos
	execute_commands(cmd4);

	// Liberar memoria
	// close(input_fd);
	// close(output_fd);
	// free(cmd1);
	// free(cmd2);
	// free(cmd3);
	free(cmd4);
	free(heredoc_content);

	return 0;
} */

// int main(void)
// {
//     // Comando 1: cat input.txt
//     char *args1[] = {"cat", "input.txt", NULL};
//     int input_fd = open("input.txt", O_RDONLY);
//     t_command *cmd1 = create_command(args1, input_fd, STDOUT_FILENO, 0, NULL);

//     // Comando 2: grep minishell
//     char *args2[] = {"grep", "minishell", NULL};
//     t_command *cmd2 = create_command(args2, STDIN_FILENO, STDOUT_FILENO, 0, NULL);

//     // Comando 3: wc -l >> output.txt (append)
//     char *args3[] = {"wc", "-l", NULL};
//     int output_fd = open("output.txt", O_WRONLY | O_CREAT | O_APPEND, 0644);
//     t_command *cmd3 = create_command(args3, STDIN_FILENO, output_fd, 1, NULL);

//     // Comando 4: heredoc
//     char *args4[] = {"cat", NULL};
//     char *heredoc_content = read_heredoc("EOF");
//     t_command *cmd4 = create_command(args4, STDIN_FILENO, STDOUT_FILENO, 0, heredoc_content);

//     // Configurar pipes
//     cmd1->next = cmd2;
//     cmd2->next = cmd3;
//     cmd3->next = cmd4;

//     // Ejecutar comandos
//     execute_commands(cmd1);

//     // Liberar memoria
//     close(input_fd);
//     close(output_fd);
//     free(cmd1);
//     free(cmd2);
//     free(cmd3);
//     free(cmd4);
//     free(heredoc_content);

//     return 0;
// }
