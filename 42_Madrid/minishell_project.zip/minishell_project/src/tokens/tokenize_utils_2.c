/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenize_utils_2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/18 12:16:11 by frromero          #+#    #+#             */
/*   Updated: 2025/02/18 12:19:45 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Calculates length of content between matching quote characters
 * @param in Input string being processed
 * @param i Pointer to starting quote position (updated to post-closing quote)
 * @param quote_char Either single (') or double (") quote delimiter
 * @return int Length of quoted content (excluding delimiters)
 */
int get_quoted_word_length(char *in, int *i, char quote_char)
{
	int length;
	int start;

	start = *i;
	length = 0;
	(*i)++;
	while (in[*i] && in[*i] != quote_char)
	{
		(*i)++;
		length++;
	}
	if (in[*i] == quote_char)
		(*i)++;
	return (length);
}

/**
 * @brief Creates WORD token from quoted content
 * @param in Input string containing quotes
 * @param start Index of opening quote character
 * @param length Number of characters between quotes
 * @return t_token* New token with quoted content (without delimiters)
 */
t_token *create_token_word(char *in, int start, int length)
{
	t_token *new_token;
	char *word;
	int j;

	j = 0;
	word = malloc(length + 1);
	if (!word)
		return (NULL);
	while (j < length)
	{
		word[j] = in[start + 1 + j];
		j++;
	}
	word[length] = '\0';
	new_token = create_token_node(word, WORD);
	free(word);
	return (new_token);
}

/**
 * @brief Handles quoted content processing for both quote types
 * @param in Input string being processed
 * @param i Pointer to starting quote position
 * @param quote_char Quote type to handle (' or ")
 * @return t_token* New token with processed quoted content
 */
t_token *handle_quoted_word(char *in, int *i, char quote_char)
{
	int start;
	int length;

	start = *i;
	length = get_quoted_word_length(in, i, quote_char);
	return (create_token_word(in, start, length));
}

/**
 * @brief Processes single-quoted content tokenization
 * @param in Input string being processed
 * @param i Pointer to starting quote position
 * @return t_token* New token with literal quoted content
 */
t_token *handle_single_quoted_word(char *in, int *i)
{
	return (handle_quoted_word(in, i, S_QUOTE));
}

/**
 * @brief Processes double-quoted content tokenization
 * @param in Input string being processed
 * @param i Pointer to starting quote position
 * @return t_token* New token with expanded quoted content
 */
t_token *handle_double_quoted_word(char *in, int *i)
{
	return (handle_quoted_word(in, i, QUOTE));
}
