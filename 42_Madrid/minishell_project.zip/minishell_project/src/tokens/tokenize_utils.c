/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenize_utils.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/13 17:25:44 by frromero          #+#    #+#             */
/*   Updated: 2025/02/23 12:06:37 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Prints the list of tokens.
 * Loops through the list and prints each node's value.
 */
void print_token_list(t_token *token_list)
{
	t_token *current;

	current = token_list;
	if (!current)
	{
		printf("--> The list is empty.\n");
		return ;
	}
	while (current)
	{
		printf("%s\n", current->value);
		if(current->type == WORD)
			printf("WORD\n");
		if(current->type == PIPE)
			printf("PIPE \n");
		if(current->type == REDIR_IN)
			printf("REDIR_IN \n");
		if(current->type == REDIR_OUT)
			printf("REDIR_OUT \n");
		if(current->type == REDIR_APPEND)
			printf("REDIR_APPEND \n");
		if(current->type == HEREDOC)
			printf("HEREDOC \n");
		current = current->next;
	}
}

/**
 * @brief Creates a new token node
 * Allocates memory for the node and stores values.
 */
t_token *create_token_node(char *token, t_token_type type)
{
	t_token *token_node;

	if (!token)
		return (NULL);
	token_node = (t_token *)malloc(sizeof(t_token));
	if (!token_node)
		return (NULL);
	token_node->value = ft_strdup(token);
	token_node->type = type;
	if (!token_node->value)
	{
		free(token_node);
		return (NULL);
	}
	token_node->next = NULL;
	return (token_node);
}

/**
 * @brief Adds a new token node to the end of the list.
 * If the list is empty, the new node becomes the first node.
 */
void add_token_node_to_list(t_token **token_list, t_token *new_node)
{
	t_token *temp;

	if (!token_list || !new_node)
		return ;
	if (!*token_list)
	{
		*token_list = new_node;
		return ;
	}
	temp = *token_list;
	while (temp->next)
		temp = temp->next;
	temp->next = new_node;
}
