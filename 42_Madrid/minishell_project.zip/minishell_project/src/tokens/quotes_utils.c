/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   quotes_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/18 12:12:51 by frromero          #+#    #+#             */
/*   Updated: 2025/02/20 16:16:59 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Checks if a character is a quote.
 * @param c Character to check.
 * @return int 1 if the character is a quote, 0 otherwise.
 */
static int is_quote(char c)
{
	return (c == '\'' || c == '"');
}

/**
 * @brief Checks if the current character is an escape sequence.
 * @param in_quote Current quote state.
 * @param current_char Character to check.
 * @return int 1 if the character is an escape sequence, 0 otherwise.
 */
int static is_escape_sequence(char in_quote, char current_char)
{
	return (current_char == '\\' && in_quote == '"');
}
/**
 * @brief Updates the quote state based on the current character.
 * @param in_quote Current quote state.
 * @param current_char Character to check.
 * @return char Updated quote state.
 */
static char update_quote_state(char in_quote, char current_char)
{
	if (current_char == in_quote)
		return 0;	 // Se cierra la comilla
	return in_quote; // Mantiene el estado actual
}
/**
 * @brief Gets the unclosed quote character in a string.
 * @param str Input string.
 * @return char Unclosed quote character, or 0 if all quotes are closed.
 */
char get_unclosed_quote(const char *str)
{
	char in_quote;
	int escape;
	size_t i;

	in_quote = 0;
	escape = 0;
	i = 0;
	while (str[i])
	{
		if (escape)
			escape = 0;
		else
		{
			if (in_quote)
				in_quote = update_quote_state(in_quote, str[i]);
			else if (is_quote(str[i]))
				in_quote = str[i];
			if (is_escape_sequence(in_quote, str[i]))
				escape = 1;
		}
		i++;
	}
	return (in_quote);
}

/**
 * @brief Gets the prompt message based on the unclosed quote character.
 * @param unclosed_quote Unclosed quote character.
 * @return char* Prompt message.
 */
char *get_prompt_message(char unclosed_quote)
{
	if (unclosed_quote == '\'')
		return "quote> ";
	return ("dquote> ");
}
