/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenize_quote.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/13 19:29:47 by frromero          #+#    #+#             */
/*   Updated: 2025/02/20 16:18:04 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Joins the full command with a new line.
 * @param full_cmd Full command entered by the user.
 * @param line New line to join with the full command.
 * @return char* New command with the joined line, or NULL if there is an error.
 */
static char *join_commands(char *full_cmd, char *line)
{
	size_t new_size;
	char *new_cmd;

	new_size = strlen(full_cmd) + strlen(line) + 2; // +2 para '\n' y '\0'
	new_cmd = malloc(new_size);
	if (!new_cmd)
	{
		perror("malloc");
		return (NULL);
	}
	// Copia y concatena las cadenas
	ft_strlcpy(new_cmd, full_cmd, new_size);
	ft_strlcat(new_cmd, "\n", new_size);
	ft_strlcat(new_cmd, line, new_size);

	return (new_cmd);
}

/**
* @brief Handles unclosed quotation marks in the user's command.
* @param full_cmd Full command entered by the user.
* @param unclosed_quote Unclosed quotation mark character.
* @return char* A full command with closed quotes, or NULL if there is an error.
*/
static char *handle_unclosed_quotes(char *full_cmd, char unclosed_quote)
{
	char *line;
	char *new_cmd;
	char *prompt;

	while (unclosed_quote != 0)
	{
		prompt = get_prompt_message(unclosed_quote);
		line = readline(prompt);
		if (!line)
		{
			free(full_cmd);
			return (NULL);
		}
		new_cmd = join_commands(full_cmd, line);
		free(full_cmd);
		free(line);
		if (!new_cmd)
		{
			return (NULL);
		}
		full_cmd = new_cmd;
		unclosed_quote = get_unclosed_quote(full_cmd);
	}
	return (full_cmd);
}

/**
* @brief Gets the complete command from the user, handling unclosed quotes.
* @param shell Structure that contains the state of the shell.
*/
void get_full_command(t_shell *shell)
{
	char *full_cmd;
	char unclosed_quote;

	full_cmd = readline(GREEN "minishell> " RESET);
	if (!full_cmd)
	{
		close_shell(shell);
		return ;
	}
	unclosed_quote = get_unclosed_quote(full_cmd);
	full_cmd = handle_unclosed_quotes(full_cmd, unclosed_quote);
	if (!full_cmd)
	{
		close_shell(shell);
		return ;
	}
	shell->input_user = full_cmd;
}

