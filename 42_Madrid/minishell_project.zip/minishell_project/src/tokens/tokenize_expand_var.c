/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenize_expand_var.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/15 17:10:18 by frromero          #+#    #+#             */
/*   Updated: 2025/02/19 19:51:33 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Retrieves environment variable value from shell context
 * @param shell Shell context containing environment variables
 * @param var_name Name of environment variable to find
 * @return char* Value of variable if found, NULL otherwise
 */
static char *get_env_value(t_shell *shell, char *var_name)
{
	t_enviroment *current;
	int var_len;

	if (!shell || !shell->env || !var_name)
		return (NULL);
	current = shell->env;
	var_len = ft_strlen(var_name);
	while (current)
	{
		if (ft_strncmp(current->value, var_name, var_len) == 0 && current->value[var_len] == '=')
			return (current->value + var_len + 1);
		current = current->next;
	}
	return (NULL);
}

/**
 * @brief Expands environment variable from input string
 * @param in Input string containing variable reference
 * @param i Pointer to position of '$' character in input
 * @param shell Shell context for environment lookup
 * @return char* Expanded value or empty string if not found
 */
char *expand_var(char *in, int *i, t_shell *shell)
{
	int start;
	char *var_name;
	char *var_value;

	if (!in || !i || in[*i] != DOLLAR)
		return (NULL);
	start = ++(*i);
	if (!in[*i] || !(ft_isalnum(in[*i]) || in[*i] == '_'))
		return (ft_strdup("$"));

	while (in[*i] && (ft_isalnum(in[*i]) || in[*i] == '_'))
		(*i)++;
	var_name = ft_substr(in, start, *i - start);
	var_value = get_env_value(shell, var_name);
	free(var_name);
	if (!var_value)
		return (ft_strdup(""));
	return (ft_strdup(var_value));
}
