/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenize_handle_word.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/12 10:30:23 by frromero          #+#    #+#             */
/*   Updated: 2025/02/19 12:07:08 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Creates a WORD token from a substring of the input
 * @param in Input string being processed
 * @param start Starting index of the word in input string
 * @param length Number of characters to include in the token
 * @return t_token* New WORD token, or NULL on allocation failure
 */
static t_token *handle_plain_word(char *in, int start, int length)
{
	char *word;
	t_token *new_token;

	word = ft_substr(in, start, length);
	new_token = create_token_node(word, WORD);  // revisar almacenamiento types TODOS SE ALMACENAN COMO WORD
	free(word);
	return (new_token);
}

/**
 * @brief Processes contiguous characters into a WORD token
 * @param in Input string being processed
 * @param i Pointer to current position index (updated to end of word)
 * @return t_token* New WORD token containing all characters until delimiter
 */
t_token *handle_word(char *in, int *i)
{
	int start;
	int length;
	t_token *new_token;

	start = *i;
	length = 0;
	new_token = NULL;
	while (in[*i] && !ft_strchr(" \t\n|><", in[*i]))
	{
		(*i)++;
		length++;
	}
	new_token = handle_plain_word(in, start, length);
	return (new_token);
}
