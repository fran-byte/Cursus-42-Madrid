/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenize.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/08 10:30:23 by frromero          #+#    #+#             */
/*   Updated: 2025/02/19 19:45:32 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Handles output redirection tokenization.
 * @param in Input string being processed
 * @param i Pointer to current position index
 * @return t_token* > token (REDIR_OUT) or >> token (REDIR_APPEND)
 */
static t_token *handle_redir_out(char *in, int *i)
{
	if (in[*i + 1] == OUT)
	{
		(*i)++;
		return (create_token_node(">>", REDIR_APPEND));
	}
	return (create_token_node(">", REDIR_OUT));
}

/**
 * @brief Handles input redirection tokenization.
 * @param in Input string being processed
 * @param i Pointer to current position index
 * @return t_token* < token (REDIR_IN) or << token (HEREDOC)
 */
static t_token *handle_redir_in(char *in, int *i)
{
	if (in[*i + 1] == IN)
	{
		(*i)++;
		return (create_token_node("<<", HEREDOC));
	}
	return (create_token_node("<", REDIR_IN));
}

/**
 * @brief Identifies and creates next token in input string
 * @param in Input string being processed
 * @param i Pointer to current position index
 * @param shell Shell context (unused in current implementation)
 * @return t_token* New token of identified type (PIPE, REDIR, QUOTE, WORD)
 */
static t_token *get_next_token(char *in, int *i, t_shell *shell)
{
	if (in[*i] == PIPES)
		return (create_token_node("|", PIPE));
	else if (in[*i] == OUT)
		return (handle_redir_out(in, i));
	else if (in[*i] == IN)
		return (handle_redir_in(in, i));
	else if (in[*i] == QUOTE)
		return (handle_double_quoted_word(in, i));
	else if (in[*i] == S_QUOTE)
		return (handle_single_quoted_word(in, i));
	else
		return (handle_word(in, i));
}

/**
 * @brief Converts input string into linked list of tokens
 * @param shell Shell context to store resulting tokens
 * @param in Input string to tokenize
 * @return int Always returns 1 (success status)
 */
int tokenize_input(t_shell *shell, char *in)
{
	int i;
	t_token *token_list;
	t_token *new_token;

	i = 0;
	token_list = NULL;
	new_token = NULL;
	while (in[i])
	{
		if (in[i] == SPC || in[i] == TABS)
			i++;
		else
		{
			new_token = get_next_token(in, &i, shell);
			if (new_token)
				add_token_node_to_list(&token_list, new_token);
			if (in[i] != '\0')
				i++;
		}
	}
	shell->tokens = token_list;
	return (1);
}
