/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mini_export.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/15 13:29:54 by frromero          #+#    #+#             */
/*   Updated: 2025/02/23 20:58:30 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Adds a new environment variable to the minishell's environment list.
 * Creates a node for the new variable and adds it to the list.
 * @param shell Shell context containing skip_execution and add_env_node_to_list
 * @param new_variable valriable to add
 * @return 0 on success, 1 on failure.
 */
static int add_new_variable_to_env(t_shell *shell, char *new_variable)
{
	t_enviroment *env_node;
	t_enviroment *env_list;

	env_list = shell->env;
	env_node = create_env_node(new_variable);
	if (!env_node)
	{
		free(new_variable);
		shell->skip_execution = 1;
		return (1);
	}
	add_env_node_to_list(&env_list, env_node);
	shell->skip_execution = 0;
	return (0);
}

/**
 * @brief Adds an environment variable to the minishell's environment list.
 * Creates a new variable in the format "name=value" and adds it to the list.
 * @param shell
 * @param name name of the variable to add
 * @param value value of the variable
 * @return 0 on success, 1 on failure.
 */
int export_env_var(t_shell *shell, char *name, char *value)
{
	char *new_variable;
	int len;

	printf("\nDEBUGGUER LINE: 'mini_export'\n\n");
	if (!name || !value)
		return (perror("<-- Error: name/value: null\n"), shell->skip_execution = 1, 1);
	len = ft_strlen(name) + 1 + ft_strlen(value) + 1;
	new_variable = malloc(len);
	if (!new_variable)
	{
		perror("<-- Error: Could not allocate memory\n");
		return (shell->skip_execution = 1, 1);
	}
	ft_bzero(new_variable, len);
	ft_strlcpy(new_variable, name, len);
	ft_strlcat(new_variable, "=", len);
	ft_strlcat(new_variable, value, len);
	if (add_new_variable_to_env(shell, new_variable))
	{
		perror("<-- Error: Could not add variable to env\n");
		free(new_variable);
		return (shell->skip_execution = 1), (1);
	}
	free(new_variable);
	return (shell->skip_execution = 0, 0);
}

/**
 * @brief Adds an environment variable to the minishell's environment list.
 * Creates a new variable in the format "name=value" and adds it to the list.
 * @param shell
 * @param name name of the variable to add
 * @param value value of the variable
 * @return 0 on success, 1 on failure.
 */
int export_env_var_one_arg(t_shell *shell, char *arg)//CORREGIR NO HACER CON SPLIT cuando encuentre  un = manejar el segundo argumento
{
	char *new_variable;
	int len;
	char **arg_export;

	arg_export = ft_split(arg, '=');
	printf("\nDEBUGGUER LINE: 'mini_export'\n\n");
	if (!arg_export[0] || !arg_export[1])
	{
		return (perror("<-- Error: name/value: null\n"), shell->skip_execution = 1, 1);
		ft_free_tab(arg_export);
	}
	len = ft_strlen(arg_export[0]) + 1 + ft_strlen(arg_export[1]) + 1;
	new_variable = malloc(len);
	if (!new_variable)
	{
		perror("<-- Error: Could not allocate memory\n");
		return (shell->skip_execution = 1, 1);
	}
	ft_bzero(new_variable, len);
	ft_strlcpy(new_variable, arg_export[0], len);
	ft_strlcat(new_variable, "=", len);
	ft_strlcat(new_variable, arg_export[1], len);
	if (add_new_variable_to_env(shell, new_variable))
	{
		perror("<-- Error: Could not add variable to env\n");
		free(new_variable);
		ft_free_tab(arg_export);
		return (shell->skip_execution = 1), (1);
	}
	ft_free_tab(arg_export);
	free(new_variable);
	return (shell->skip_execution = 0, 0);
}
