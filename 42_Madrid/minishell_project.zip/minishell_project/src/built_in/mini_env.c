/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mini_env.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/21 08:02:35 by frromero          #+#    #+#             */
/*   Updated: 2025/02/23 20:23:44 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Prints the list of environment variables.
 * Loops through the list and prints each node's value.
 */
int print_env_list(t_enviroment *path_list, t_shell *shell)
{
	t_enviroment *current;

	printf("\nDEBUGUER LINE: 'mini_env'\n\n");
	current = path_list;
	if (!current)
	{
		printf("--> The list is empty.\n");
		shell->skip_execution = 1;
		return (1);
	}
	while (current)
	{
		printf("%s\n", current->value);
		current = current->next;
	}
	shell->skip_execution = 0;
	return (0);
}
