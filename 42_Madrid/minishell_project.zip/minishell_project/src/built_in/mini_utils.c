/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mini_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/22 13:55:27 by frromero          #+#    #+#             */
/*   Updated: 2025/02/22 13:55:46 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

char *get_env_var(t_shell *shell, char *var)
{
	t_enviroment *current;

	if (!shell || !shell->env || !var)
		return (NULL);

	current = shell->env;
	while (current)
	{
		if (ft_strncmp(current->value, var, ft_strlen(var)) == 0
			&& current->value[ft_strlen(var)] == '=')
		{
			return (current->value + ft_strlen(var) + 1); // Devuelve el valor después del '='
		}
		current = current->next;
	}
	return (NULL);
}
