/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mini_pwd.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/19 18:24:41 by frromero          #+#    #+#             */
/*   Updated: 2025/02/23 20:06:54 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Retrieves the current working directory.
 * Allocates a buffer dynamically and resizes it if necessary to store the full
 * path.
 * @param void
 * @return the path as a string on success, or NULL on failure.
 */
char *get_pwd(void)
{
	size_t size;
	char *buffer;

	size = 1024;
	buffer = NULL;
	while (1)
	{
		buffer = (char *)malloc(size);
		if (buffer == NULL)
		{
			perror("<-- Error: malloc");
			return (NULL);
		}
		if (getcwd(buffer, size) != NULL)
			return (buffer);
		else
		{
			free(buffer);
			size *= 2; // Duplicar el tamaño del buffer y reintentar la captura de nuevo
		}
	}
}
/**
 * @brief Prints the current working directory.
 * @param shell Shell context containing skip_execution
 *
 * Uses get_pwd to retrieve the directory and prints it to the standard output.
 * Updates the shell's skip_execution flag based on success or failure.
 * @return 0 on success, 1 on failure.
 */
int print_pwd(t_shell *shell)
{
	char *pwd;



	pwd = NULL;
	pwd = get_pwd();
	if (!pwd)
	{
		shell->skip_execution = 1;
		return (1);
	}
	printf("%s\n", pwd);
	printf("\nDEBUGGUER LINE: 'mini_pwd'\n");
	free(pwd);
	shell->skip_execution = 0;
	return (0);
}
