/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mini_unset.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/14 23:20:04 by frromero          #+#    #+#             */
/*   Updated: 2025/02/23 20:24:10 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

int unset_env_var(t_shell *shell, char *var)
{
	t_enviroment *current;
	t_enviroment *prev;

	printf("\nDEBUGGUER LINE: 'mini_unset'\n\n");
	prev = NULL;
	if (!shell || !shell->env || !var)
		return(shell->skip_execution = 1, 1);
	current = shell->env;
	while (current)
	{
		if (ft_strncmp(current->value, var, ft_strlen(var)) == 0
			&& current->value[ft_strlen(var)] == '=')// la longitud será igual al caracter siguiente
						//es decir PATH tiene (4)  0-1-2-3-4  donde [4] es = (PATH=)
		{
			if (prev)
				prev->next = current->next;
			else
				shell->env = current->next;//si es el primer nodo cambiamos la cabecera a next
			free(current->value);
			free(current);
			return(shell->skip_execution = 1, 1);
		}
		prev = current; //Current se almacena en previo y avanzamos
		current = current->next;
	}
	return(shell->skip_execution = 0, 0);
}
