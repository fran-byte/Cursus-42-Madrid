/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mini_exit.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/21 08:18:44 by frromero          #+#    #+#             */
/*   Updated: 2025/02/23 20:26:29 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Closes the shell and resets the skip_execution flag.
 * Calls the close_shell function to perform necessary cleanup operations.
 * @param shell Shell context containing skip_execution
 * @return 0 on success.
 */
int get_away(t_shell *shell)
{
	printf("\nDEBUGGUER LINE: 'mini_exit'\n");
	close_shell(shell);
	shell->skip_execution = 0;
	return (0);
}
