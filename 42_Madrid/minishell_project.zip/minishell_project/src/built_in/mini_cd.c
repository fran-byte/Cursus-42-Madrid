/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mini_cd.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/21 08:46:49 by frromero          #+#    #+#             */
/*   Updated: 2025/02/23 20:24:26 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

// IN PROGRESS------------------------
//*** HAY QUE AÑADIR cd ../.. de momento se queda PENDIENTE ******

// cambia el directorio y actualiza las variables de entorno y la ruta FISICA IMPORTATE  !!
int change_directory(t_shell *shell, char *new_directory)
{
	char *pwd;
	char *new_pwd;
	char *current_dir;

	printf("\nDEBUGGUER LINE: 'mini_cd'\n\n");
	pwd = NULL;
	pwd = get_pwd(); // Obtener el directorio actual
	if (!pwd)
	{
		shell->skip_execution = 1;
		return (1);
	}
	if (chdir(new_directory) != 0) // Intentar cambiar el directorio
	{
		perror("<-- error: chdir");
		shell->skip_execution = 1;
		return (1);
	}
	// Si la entrada es una ruta absoluta, NO MODIFICAMOS.
	if (new_directory[0] == '/')
	{
		unset_env_var(shell, "OLDPWD");				 // Borra OLD_PWD
		export_env_var(shell, "OLDPWD", pwd);		 // Actualiza OLD_PWD con directorio actual
		unset_env_var(shell, "PWD");				 // Borra PWD
		export_env_var(shell, "PWD", new_directory); // Actualizar PWD con new_directory
	}
	else	// Si la entrada es relativa, CONCATENAMOS
	{
		char *new_pwd = malloc(ft_strlen(pwd) + ft_strlen(new_directory) + 2); // +2 uno para '/' y '\0'
		if (new_pwd)
		{
			unset_env_var(shell, "OLDPWD");
			export_env_var(shell, "OLDPWD", pwd);
			unset_env_var(shell, "PWD");
			export_env_var(shell, "PWD", new_pwd);
			free(new_pwd);
		}
	}
	// Actualiza RUTA FISICA
	current_dir = getcwd(NULL, 0); // Obtener el directorio actual
	if (current_dir)
	{
		unset_env_var(shell, "PWD");
		export_env_var(shell, "PWD", current_dir); // Actualizamos PWD con la ruta física actual
		free(current_dir);
	}
	shell->skip_execution = 0;
	free(pwd);
	return (0);
}
