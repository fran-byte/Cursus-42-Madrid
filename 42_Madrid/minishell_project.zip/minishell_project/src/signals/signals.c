/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   signals.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/10 18:47:31 by frromero          #+#    #+#             */
/*   Updated: 2025/02/18 20:51:27 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Handles the SIGINT (Ctrl-C) signal.
 *
 * This function prevents the shell from exiting when Ctrl-C is pressed.
 * Instead, it resets the input line and moves the cursor to a new line.
 *
 * @param sig The signal number (unused).
 */
void handle_sigint(int sig)
{
	(void)sig;
	write(STDOUT_FILENO, "\n", 1); // Añadir un salto de línea explícito
	rl_replace_line("", 0);		   // Reemplaza la línea actual con una línea vacía
	rl_on_new_line();			   // Mueve el cursor a una nueva línea
	rl_redisplay();				   // Redibuja la línea de entrada
}

/**
 * @brief Sets up signal handlers for the shell.
 *
 * Configures the handling of SIGINT (Ctrl-C) to prevent shell termination
 * and ignores SIGQUIT (Ctrl-\).
 */
void setup_signal_handlers(void)
{
	signal(SIGINT, handle_sigint); // `Ctrl-C` no mata el shell, solo marca `g_signal_flag`
	signal(SIGQUIT, SIG_IGN);
}
