/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtin.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/22 13:55:38 by user              #+#    #+#             */
/*   Updated: 2025/02/23 20:54:48 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

int execute_builtin(t_command *cmd, t_shell *shell)
{
	if (!cmd || !cmd->args || !cmd->args[0])
		return (1);

	if (!ft_strcmp(cmd->args[0], "echo"))
		return (print_env_list(shell->env, shell));
	if (!ft_strcmp(cmd->args[0], "cd"))
		return (change_directory(shell, cmd->args[1]));
	if (!ft_strcmp(cmd->args[0], "pwd"))
	{
		char *pwd = get_pwd();
		if (pwd)
		{
			printf("%s\n", pwd);
			free(pwd);
			return (0);
		}
		return (1);
	}
	if (!ft_strcmp(cmd->args[0], "export"))
		return (export_env_var_one_arg(shell, cmd->args[1]));
	if (!ft_strcmp(cmd->args[0], "unset"))
		return (unset_env_var(shell, cmd->args[1]));
	if (!ft_strcmp(cmd->args[0], "env"))
		return (print_env_list(shell->env, shell));
	if (!ft_strcmp(cmd->args[0], "exit"))
		return (get_away(shell));

	return (1);
}

int is_builtin(char *cmd)
{
	if (!cmd)
		return (0);
	if (ft_strcmp(cmd, "echo") == 0)
		return (1);
	if (ft_strcmp(cmd, "cd") == 0)
		return (1);
	if (ft_strcmp(cmd, "pwd") == 0)
		return (1);
	if (ft_strcmp(cmd, "export") == 0)
		return (1);
	if (ft_strcmp(cmd, "unset") == 0)
		return (1);
	if (ft_strcmp(cmd, "env") == 0)
		return (1);
	if (ft_strcmp(cmd, "exit") == 0)
		return (1);
	return (0);
}
