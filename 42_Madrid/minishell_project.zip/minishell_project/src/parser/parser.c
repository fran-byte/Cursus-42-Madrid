#include "../../inc/minishell.h"

/* ----------------------------- parser.c ----------------------------- */
#include "../../inc/minishell.h"

const char *token_type_to_string(t_token_type type)
{
    switch (type)
    {
        case WORD: return "WORD";
        case PIPE: return "PIPE";
        case REDIR_IN: return "REDIR_IN";
        case REDIR_OUT: return "REDIR_OUT";
        case REDIR_APPEND: return "REDIR_APPEND";
        case HEREDOC: return "HEREDOC";
        case END: return "END";
        case EMPTY: return "EMPTY";
        default: return "UNKNOWN";
    }
}

t_command *handle_heredoc(t_command *cmd, t_token *token)
{
    if (token->next)
        cmd->heredoc_content = read_heredoc(token->next->value);
    return (cmd);
}

t_command *parse_tokens(t_token *tokens)
{
    t_command *cmd_list = NULL;
    t_command *current_cmd = NULL;
    t_token *current = tokens;

    while (current)
    {
        printf("Token: %s, Type: %s\n", current->value, token_type_to_string(current->type)); // Debug print
        if (!cmd_list || current->type == PIPE)
        {
            if (current->type == PIPE)
                current = current->next;
            if (!current)
                break;
            if (!cmd_list)
            {
                cmd_list = create_cmd_node(current);
                current_cmd = cmd_list;
            }
            else
            {
                current_cmd->next = create_cmd_node(current);
                current_cmd = current_cmd->next;
            }
            continue;
        }
        if (current->type == REDIR_OUT || current->type == REDIR_APPEND)
        {
            if (current->next)
            {
                if (current->type == REDIR_APPEND)
                {
                    current_cmd->output_fd = open(current->next->value, O_WRONLY | O_CREAT | O_APPEND, 0644);
                    current_cmd->append = 1;
                }
                else
                {
                    current_cmd->output_fd = open(current->next->value, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                    current_cmd->append = 0;
                }
                current = current->next; // Mover al siguiente token después de manejar la redirección
            }
        }
        else if (current->type == REDIR_IN)
        {
            if (current->next)
            {
                current_cmd->input_fd = open(current->next->value, O_RDONLY);
                current = current->next; // Mover al siguiente token después de manejar la redirección
            }
        }
        else if (current->type == HEREDOC)
        {
            current_cmd = handle_heredoc(current_cmd, current);
            current = current->next; // Mover al siguiente token después de manejar el heredoc
        }
        else
        {
            int i = 0;
            while (current_cmd->args && current_cmd->args[i])
                i++;
            current_cmd->args = realloc(current_cmd->args, sizeof(char *) * (i + 2));
            if (current_cmd->args)
            {
                current_cmd->args[i] = current->value;
                current_cmd->args[i + 1] = NULL;
            }
        }
        current = current->next;
    }
    return (cmd_list);
}

// t_command *handle_heredoc(t_command *cmd, t_token *token)
// {
// 	if (token->next)
// 		cmd->heredoc_content = read_heredoc(token->next->value);
// 	return (cmd);
// }

// t_command *parse_tokens(t_token *tokens)
// {
//     t_command *cmd_list = NULL;
//     t_command *current_cmd = NULL;
//     t_token *current = tokens;

//     while (current)
//     {
//         if (!cmd_list || current->type == PIPE)
//         {
//             if (current->type == PIPE)
//                 current = current->next;
//             if (!current)
//                 break;
//             if (!cmd_list)
//             {
//                 cmd_list = create_cmd_node(current);
//                 current_cmd = cmd_list; // Inicializar current_cmd con el primer nodo
//             }
//             else
//             {
//                 current_cmd->next = create_cmd_node(current);
//                 current_cmd = current_cmd->next; // Mover current_cmd al siguiente nodo
//             }
//             continue;
//         }
//         if (current->type == REDIR_OUT || current->type == REDIR_APPEND)
//         {
//             if (current->type == REDIR_APPEND)
//             {
//                 current_cmd->output_fd = open(current->next->value, O_WRONLY | O_CREAT | O_APPEND, 0644);
//                 current_cmd->append = 1;
//             }
//             else
//             {
//                 current_cmd->output_fd = open(current->next->value, O_WRONLY | O_CREAT | O_TRUNC, 0644);
//                 current_cmd->append = 0;
//             }
//         }
//         else if (current->type == REDIR_IN)
//         {
//             current_cmd->input_fd = open(current->next->value, O_RDONLY);
//         }
//         else if (current->type == HEREDOC)
//         {
//             current_cmd = handle_heredoc(current_cmd, current);
//         }
//         else
//         {
//             int i = 0;
//             while (current_cmd->args && current_cmd->args[i])
//                 i++;
//             current_cmd->args = realloc(current_cmd->args, sizeof(char *) * (i + 2));
//             if (current_cmd->args)
//             {
//                 current_cmd->args[i] = current->value;
//                 current_cmd->args[i + 1] = NULL;
//             }
//         }
//         current = current->next;
//     }
//     return (cmd_list);
// }