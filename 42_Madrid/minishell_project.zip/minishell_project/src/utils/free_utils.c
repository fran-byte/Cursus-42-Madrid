/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/08 23:52:04 by frromero          #+#    #+#             */
/*   Updated: 2025/02/20 11:21:04 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Frees an array of strings (tab).
 * Iterates through the array and frees each string, then the array itself.
 */
void ft_free_tab(char **tab)
{
	int i;

	i = 0;
	if (tab)
	{
		while (tab[i])
		{
			free(tab[i]);
			i++;
		}
		free(tab);
	}
}
/**
 * @brief Frees all nodes in the environment list.
 * Iterates through the list and frees both the value and the node itself.
 */
void free_env_list(t_enviroment **env_list)
{
	t_enviroment *temp;
	t_enviroment *current;

	if (!env_list || !*env_list)
		return;
	current = *env_list;
	while (current)
	{
		temp = current->next;
		free(current->value);
		free(current);
		current = temp;
	}
	*env_list = NULL;
}
/**
 * @brief Frees all nodes in the token list.
 * Iterates through the list and frees both the value and the node itself.
 */
void free_token_list(t_token **token_list)
{
	t_token *temp;
	t_token *current;

	if (!token_list || !*token_list)
		return;

	current = *token_list;
	while (current)
	{
		temp = current->next;
		free(current->value);
		free(current);
		current = temp;
	}
	*token_list = NULL;
}
void free_cmd_list(t_command **cmd_list)
{
	t_command *temp;
	t_command *current;

	if (!cmd_list || !*cmd_list)
		return;
	current = *cmd_list;
	while (current)
	{
		temp = current->next;
		if (current->args)
		{
			int i = 0;
			while (current->args[i])
			{
				free(current->args[i]);
				i++;
			}
			free(current->args);
		}
		free(current->heredoc_content);
		free(current);
		current = temp;
	}
	*cmd_list = NULL;
}
