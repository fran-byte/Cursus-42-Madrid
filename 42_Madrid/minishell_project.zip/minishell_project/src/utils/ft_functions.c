/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_functions.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/19 18:14:20 by frromero          #+#    #+#             */
/*   Updated: 2025/02/22 20:44:14 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Copies a string from source to destination
 * @param dest Pointer to the destination buffer
 * @param src Pointer to the source string to be copied
 * @return A pointer to the destination string, or NULL if dest or src is NULL
 */
char *ft_strcpy(char *dest, const char *src)
{
	char *original_dest;

	if (!dest || !src)
		return NULL;
	(original_dest = dest);
	while (*src)
	{
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
	return (original_dest);
}

/**
 * @brief Compares two strings lexicographically
 * @param s1 First string to compare
 * @param s2 Second string to compare
 * @return An integer less than, equal to, or greater than zero if s1 is found,
 *			respectively, to be less than, to match, or be greater than s2.
 *			Returns 1 or -1 if one of the strings is NULL.
 */
int ft_strcmp(const char *s1, const char *s2)
{
	if (!s1 || !s2)
	{
		if (s1 == s2)
			return (0);
		if (s1)
			return (1);
		return (-1);
	}
	while (*s1 && *s2 && (*s1 == *s2))
	{
		s1++;
		s2++;
	}
	return ((int)((unsigned char)*s1 - (unsigned char)*s2));
}

/**
 * @brief Reallocates a memory block to a new size
 * @param ptr Pointer to the previously allocated memory block
 * @param old_size The size of the original memory block
 * @param new_size The new size to allocate
 * @return A pointer to the newly allocated memory, or NULL if allocation fails
 * 			 or new_size is 0
 */
void *ft_realloc(void *ptr, size_t old_size, size_t new_size)
{
	void *new_ptr;

	if (new_size == 0)
	{
		free(ptr);
		return (NULL);
	}
	new_ptr = malloc(new_size);
	if (!new_ptr)
		return (NULL);
	if (ptr)
	{
		if (old_size < new_size)
			ft_memcpy(new_ptr, ptr, old_size);
		else
			ft_memcpy(new_ptr, ptr, new_size);
		free(ptr);
	}
	return (new_ptr);
}
