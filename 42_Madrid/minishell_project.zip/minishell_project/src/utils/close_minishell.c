/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   close_minishell.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/09 16:28:50 by frromero          #+#    #+#             */
/*   Updated: 2025/02/20 17:13:55 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

/**
 * @brief Cleans up and exits the shell.
 * Frees memory and clears the history.
 */
void close_shell(t_shell *shell)
{
	rl_clear_history();
	free_env_list(&shell->env_path);
	free_env_list(&shell->env);
	free_token_list(&shell->tokens);
	printf("\n\033[1;32m--> Minishell exiting...\033[0m");
	printf(" Your commands rest in peace");
	printf(" (until next time)!\n\n");
	printf("\033[0m");
	exit(0);
}
