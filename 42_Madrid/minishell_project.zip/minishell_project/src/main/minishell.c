/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/03 20:03:36 by frromero          #+#    #+#             */
/*   Updated: 2025/02/23 20:21:34 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minishell.h"

int handle_user_input(t_shell *shell)
{
	t_command *cmd_list;
	get_full_command(shell);
	if (*shell->input_user) // Si la entrada no está vacía, se agrega al historial
		update_history(shell);

	// // ********** Simples TEST para verificar subrrutinas PENDIENTES DE ELIMIANR************************
	// //  si el comando es "path", imprime el contenido de la lista del PATH de entorno
	// if (ft_strncmp(shell->input_user, "path", 4) == 0)
	// 	print_env_list(shell->env_path, shell);  //Imprime el path
	// // si el comando es "token", YA NO FUNCIONA este TEST PORQUE DEBIAMOS LIBERAR LOS TOKENS DESPUES de CADA VUELTA imprime el contenido de los tokens de la ultima linea (esta creado en una lista)
	// if (ft_strncmp(shell->input_user, "token", 5) == 0)
	// {
	// 	print_token_list(shell->tokens); // Ahora solo imprimimos a modo de prueba
	// 	free_token_list(&shell->tokens); // NECESARIO DESPUES DE TRABAJAR CON UN TOKEN!!
	// }
	// if (ft_strncmp(shell->input_user, "exit", 4) == 0)
	// 	get_away(shell); //Imprime path actual
	// if (ft_strncmp(shell->input_user, "cd", 2) == 0)
	// 	change_directory(shell, "/home/frromero/Documents/minishell/minishell_project/src");
	// if (ft_strncmp(shell->input_user, "pwd", 3) == 0)
	// 	print_pwd(shell); //Imprime path actual
	// if (ft_strncmp(shell->input_user, "env", 3) == 0)
	// 	print_env_list(shell->env, shell); //Imprime todas las variables de netorno
	// if (ft_strncmp(shell->input_user, "unset PATH", 10) == 0)// Si el comando es "unset PATH" borrar el nodo variable PATH
	// 	unset_env_var(shell, "PATH"); // funcion valida para nuestro BUILT-it
	// // test para incluir una nueva variable de entorno(solo la parte final hay que parsear antes la entrada claro)
	// if (ft_strncmp(shell->input_user, "export MI_VAR", 13) == 0)
	// 	export_env_var(shell, "MI_VAR", "Contenido de la nueva variable"); // funcion valida para nuestro BUILT-it
	// // TESTEANDO la expansion de la variable
	// // ******************************************************************************************************

	tokenize_input(shell, shell->input_user); // esto solo crea una lista con los tokens hay que
    expand(shell);
	cmd_list = parse_tokens(shell->tokens); // Parsear los tokens y obtener la lista de comandos
    shell->cmd_list = cmd_list;
	if(is_builtin(shell->cmd_list->args[0]))
		execute_builtin(shell->cmd_list, shell);
	else
    // Ejecutar los comandos
   		execute_commands(shell->cmd_list, shell->env); // la ejecución de programas, y las redirecciones.
	/* PARA IMPRIMIR LOS TOKENS teclar "token"  PERO: las dos lineas siguientes hay que comentarlas*/
	if(shell->tokens)
		free_token_list(&shell->tokens);// liberamos la ultima linea de tokens
	free(shell->input_user);
	return (0);
}

/*
 * Según avancemos el proyecto podemos ir inicializando las variables que se creen
 * Configurar los manejadores de señales
 * setup_signal_handlers();
 */
void initialize_shell(t_shell *shell, char **envp)
{
	shell->tokens = NULL;
	shell->env = NULL;
	shell->env_path = NULL;
	shell->history_count = 0;
	shell->input_user = NULL;
	// shell->input_fd = dup(STDIN_FILENO);
	// shell->output_fd = dup(STDOUT_FILENO);
	shell->exit_flag = 0;
	shell->return_value = 0;
	shell->skip_execution = 0;
	shell->start = 1;
	shell->env = store_env(envp);// NUEVA IMPLENTACION PARA lista de variables de entorno
	shell->env_path = store_path(envp); // Dejamos el PATH de "envp" en una lista
	create_history_file();	// crea y Carga el historial antes de empezar
}

int main(int argc, char **argv, char **envp)
{
	t_shell shell_state;

	(void)argc;
	(void)argv;
	initialize_shell(&shell_state, envp); /* Inicializamos nuestras variables*/
	// funcion para las señales
	setup_signal_handlers();
	while (!shell_state.exit_flag) /*Bucle infinito hasta que la flag sea distinto de 0, hay que trabajar el tema de las señales*/
	{

		if (handle_user_input(&shell_state)) // Esta función leerá la entrada del usuario y
			return (0);
		// Convierte la entrada en una lista de tokens (comando + argumentos)
		if (shell_state.start) // verifica si la entrada es válida(la interna o externa) antes de intentar ejecutar un comando.
							   // añadir cuando este la funcion (&& check_input(&shell_state)
		{
			; // run_shell(&shell_state); // ejecuta el comando correspondiente, gestionando las variables de entorno,
		}
	}
	close_shell(&shell_state);
	return (shell_state.return_value);
}
