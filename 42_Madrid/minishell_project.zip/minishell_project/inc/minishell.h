/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/03 19:59:44 by frromero          #+#    #+#             */
/*   Updated: 2025/02/23 20:54:44 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
#define MINISHELL_H

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/types.h>
#include <signal.h>
#include <limits.h>
#include <termios.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/param.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include <readline/history.h>
#include "../libft/libft.h"

#define QUOTE 34   /*  "  */
#define S_QUOTE 39 /*  '  */
#define PIPES 124  /*  |  */
#define OUT 62	   /*  >  */
#define IN 60	   /*  <  */
#define DOLLAR 36  /*  $  */
#define SPC 32	   /*  SPACE */
#define TABS 9	   /*  TAB */

#define HISTORY_FILE "history/history"
#define GREEN "\033[0;32m"
#define RESET "\033[0m"

typedef struct s_signal
{
	int sigint_received;
	int sigquit_received;
} t_signal;

typedef enum e_token_type
{
	WORD,		  /* Normal command or argument (e.g., "ls", "echo")*/
	PIPE,		  /* Pipe operator "|"  */
	REDIR_IN,	  /* Input redirection "<"  */
	REDIR_OUT,	  /* Output redirection ">"    */
	REDIR_APPEND, /* Append output redirection ">>"   */
	HEREDOC,	  /* Here-document redirection "<<", allows multi-line
					input until a delimiter is reached */
	END,		  /* End of line or NULL (indicates the end of parsing)*/
	EMPTY
} t_token_type;

typedef struct s_token
{
	char *value;		  // El contenido del token (ejemplo: "echo", ">", "archivo.txt")
	t_token_type type;	  // Tipo del token
	struct s_token *next; // Puntero al siguiente token (para listas enlazadas)
} t_token;

typedef struct s_command
{
	char **args;
	int input_fd;
	int output_fd;
	int append;
	char *heredoc_content;
	struct s_command *next;
} t_command;

/* Guardaremos en nuestra estructura(lista) las variables de entorno, cada nodo será una linea de string que
contendrá direcciones del entorno
Esta estructura está Funcionado*/
typedef struct s_enviroment
{
	char *value;
	struct s_enviroment *next;
} t_enviroment;

typedef struct s_shell
{
	char *input_user;
	int history_count;
	int in;
	int out;
	int exit_flag;
	int start;
	int skip_execution;
	int return_value;
	int input_fd;
	int output_fd;
	int is_parent_process;
	int is_last_command;
	t_enviroment *env_path;
	t_enviroment *env;
	t_token *tokens;
	t_command *cmd_list;
} t_shell;

typedef struct s_expand
{
	char *result;
	int j;
	size_t size;
} t_expand;

void create_history_file(void);
t_enviroment *store_path(char **envp);
void initialize_shell(t_shell *shell, char **envp);
void close_shell(t_shell *shell);
void ft_free_tab(char **tab);
void add_env_node_to_list(t_enviroment **path_list, t_enviroment *new_node);
t_enviroment *create_env_node(char *directory);
// void launch_shell(t_shell *shell);
// int should_execute_command(t_shell *shell, t_token *current_token);
// void process_redirection(t_shell *shell, t_token *current_token);
int tokenize_input(t_shell *shell, char *user_input); // PENDIENTE DE HACER ***
int print_env_list(t_enviroment *path_list, t_shell *shell);		  // Solo uso de test
void print_token_list(t_token *token_list);			  // Solo uso de test
void free_env_list(t_enviroment **env_list);
void free_token_list(t_token **token_list);
void setup_signal_handlers(void);
void handle_sigint(int sig);
void update_history(t_shell *shell);
void print_token_list(t_token *token_list);
t_token *create_token_node(char *token, t_token_type type);
void add_token_node_to_list(t_token **token_list, t_token *new_node);
t_token *handle_quoted_word(char *in, int *i, char quote_char);
t_token *handle_single_quoted_word(char *in, int *i);
t_token *handle_double_quoted_word(char *in, int *i);
t_enviroment *store_env(char **envp);
int unset_env_var(t_shell *shell, char *var);
int export_env_var(t_shell *shell, char *name, char *value);
int export_env_var_one_arg(t_shell *shell, char *arg);
char *expand_var(char *in, int *i, t_shell *shell);
t_token *handle_word(char *in, int *i);
void get_full_command(t_shell *shell);
void get_full_command(t_shell *shell);
int get_quoted_word_length(char *in, int *i, char quote_char);
t_token *create_token_word(char *in, int start, int length);
t_token *handle_quoted_word(char *in, int *i, char quote_char);
t_token *handle_single_quoted_word(char *in, int *i);
t_token *handle_double_quoted_word(char *in, int *i);
char *get_prompt_message(char unclosed_quote);
char get_unclosed_quote(const char *str);
int print_pwd(t_shell *shell);
void free_cmd_list(t_command **cmd_list);
int get_away(t_shell *shell);
int change_directory(t_shell *shell, char *new_directory);
char *get_pwd(void);
char *get_env_var(t_shell *shell, char *var);
void expand(t_shell *shell);
size_t compute_expanded_length(t_shell *shell, char *token);
char *extract_var_name(char *token, int *i);
void expand_env_value(t_expand *exp, char *exp_val);
void expand_var_or_dollar(t_shell *sh, char *tk, int *i, t_expand *exp);
void add_normal_char(t_expand *exp, char c);

// Utils
void *ft_realloc(void *ptr, size_t old_size, size_t new_size);
char *ft_strcpy(char *dest, const char *src);
int ft_strcmp(const char *s1, const char *s2);

//Ejecución de comandos
void		exe_children(t_command *current_cmd, int pipe_fd[2], int prev_fd, t_enviroment *env);
char 		*read_heredoc(const char *delimiter);
t_command 	*parse_tokens(t_token *tokens);
void 		execute_commands(t_command *cmd_list, t_enviroment *env);
t_command 	*create_cmd_node(t_token *token);
char 		*get_path(char *cmd, t_enviroment *env);
char 		**convert_env_list_to_array(t_enviroment *env);
int execute_builtin(t_command *cmd, t_shell *shell);
int is_builtin(char *cmd);

#endif
