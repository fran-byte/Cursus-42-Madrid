/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 20:31:22 by frromero          #+#    #+#             */
/*   Updated: 2024/11/23 18:51:14 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* - For these movements we send the address of the pointer, that is,
 pointer to pointer:
 pa(&lst, &lstb);  pb(&lst, &lstb); rrr(&lst, &lstb); rr(&lst, &lstb);
  -  For the rest, we send only the pointer:
 sa(lst); sb(lstb); ra(lst); rb(lstb); ss(lst, lstb); rra(lst);	rrb(lstb);*/


#include "../inc/push_swap.h"



int main(int argc, char **argv)
{
	t_list *lst = NULL;
	t_list *new_node = NULL;
	t_list *lstb = NULL;
	char	**argv_two;
	int	i;

	i = 0;
	if  (argc == 2)
	{
		argv_two = check_input_two(argc, argv);
		while (argv_two[i] != NULL)
			i++;
		init_stack_a_two(i, argv_two, new_node, &lst);
	}
	else
	{
		check_input(argc, argv);
		init_stack_a(argc, argv, new_node, &lst);
	}

	printf("\nPila a:\n");
	ft_lstiter(lst, print_numbers);
	printf("\nPila b:\n");
	ft_lstiter(lstb, print_numbers);

	printf("\nHacemos pb:\n");
	pb(&lst, &lstb);
	pb(&lst, &lstb);
	pb(&lst, &lstb);
	pb(&lst, &lstb);
	pb(&lst, &lstb);
	pb(&lst, &lstb);

	pa(&lst, &lstb);
	pa(&lst, &lstb);
	pa(&lst, &lstb);
	printf("\nPila a:\n");
	ft_lstiter(lst, print_numbers);
	printf("\n----\n");
	printf("\nPila b:\n");
	ft_lstiter(lstb, print_numbers);
	printf("\n----\n");
	sa(lst);
	sb(lstb);

	ra(lst);
	rb(lstb);

	ss(lst, lstb);

	rra(lst);
	rrb(lstb);


	rrr(&lst, &lstb);

	printf("\nPila a:\n");
	ft_lstiter(lst, print_numbers);
	printf("\n----\n");


	printf("\nPila b:\n");
	ft_lstiter(lstb, print_numbers);
	printf("\n----\n");

	rr(&lst, &lstb); /// FALLO EN ra
	//rrb(lstb);
	//rb(lst);
	printf("\nPila a:\n");
	ft_lstiter(lst, print_numbers);
	printf("\n----\n");


	printf("\nPila b:\n");
	ft_lstiter(lstb, print_numbers);
	printf("\n----\n");

	return (0);
}
