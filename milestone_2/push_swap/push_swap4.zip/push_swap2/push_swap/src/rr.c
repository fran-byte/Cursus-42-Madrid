/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rr.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 19:57:26 by frromero          #+#    #+#             */
/*   Updated: 2024/11/23 18:52:07 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*Reverse rotation (ra) and reverse rotation (rb).*/

#include "../inc/push_swap.h"

static void ra_rr(t_list *lst)
{
	t_list *current;
	int temp;

	if (!lst || !lst->next)
		return;
	temp = *lst->number;
	current = lst;
	while (current->next != NULL)
	{
		*current->number = *current->next->number;
		current = current->next;
	}
	*current->number = temp;
}

static void rb_rr(t_list *lstb)
{
	t_list *currentb;
	int tempb;

	if (!lstb || !lstb->next)
		return;
	tempb = *lstb->number;
	currentb = lstb;
	while (currentb->next != NULL)
	{
		*currentb->number = *currentb->next->number;
		currentb = currentb->next;
	}
	*currentb->number = tempb;
}

void rr(t_list **lst, t_list **lstb)
{
	ra_rr(*lst);
	rb_rr(*lstb);
	write(1, "rr\n", 3);
}
