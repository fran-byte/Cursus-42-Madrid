/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 22:49:16 by frromero          #+#    #+#             */
/*   Updated: 2024/11/20 10:54:01 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
#define PUSH_SWAP_H

typedef struct s_list
{
	int *number;
	struct s_list *prev;
	struct s_list *next;
}t_list;

#include <unistd.h>
#include <stdlib.h>
#include <limits.h>

#include <stdio.h>	// borrar
#include <string.h> // borrar

void	program_error();
void	program_exit();
int	ft_atoi(const char *str);
void	check_input(int argc, char **argv);
void	init_stack_a(int argc, char **argv, t_list *new_node, t_list *lst);
void	ft_lstadd_back(t_list **lst, t_list *new);
void	ft_lstadd_front(t_list **lst, t_list *new);
void	ft_lstclear(t_list **lst, void (*del)(void*));
void	ft_lstdelone(t_list *lst, void (*del)(void*));
void	ft_lstiter(t_list *lst, void (*f)(void *));
t_list	*ft_lstlast(t_list *lst);
t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *));
t_list	*ft_lstnew(int *number);
int	ft_lstsize(t_list *lst);

#endif
