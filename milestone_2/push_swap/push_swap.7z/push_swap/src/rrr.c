/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rrr.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 19:57:26 by frromero          #+#    #+#             */
/*   Updated: 2024/11/23 16:42:55 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*Reverse rotation (rra) and reverse rotation (rrb).*/

#include "../inc/push_swap.h"

static void rra_rrr(t_list *lst)
{
	t_list *current;
	t_list *last;
	int temp;

	if (!lst || !lst->next)
		return;
	last = ft_lstlast(lst);
	temp = *last->number;
	current = last->prev;
	while (current != NULL)
	{
		*current->next->number = *current->number;
		current = current->prev;
	}
	*lst->number = temp;
}

static void rrb_rrr(t_list *lstb)
{
	t_list *currentb;
	t_list *lastb;
	int tempb;

	if (!lstb || !lstb->next)
		return;
	lastb = ft_lstlast(lstb);
	tempb = *lastb->number;
	currentb = lastb->prev;
	while (currentb != NULL)
	{
		*currentb->next->number = *currentb->number;
		currentb = currentb->prev;
	}
	*lstb->number = tempb;
}

void rrr(t_list **lst, t_list **lstb)
{
	rra_rrr(*lst);
	rrb_rrr(*lstb);
	write(1, "rrr\n", 4);
}
