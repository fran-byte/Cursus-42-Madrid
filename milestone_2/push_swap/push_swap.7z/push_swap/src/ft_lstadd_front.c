/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_front.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/30 15:56:25 by frromero          #+#    #+#             */
/*   Updated: 2024/11/20 07:47:34 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* Adds the node 'new' to the beginning of the linked list 'lst'. The 'next'
   pointer of the new node is updated to point to the current first node,
   and the head of the list is updated to the new node.*/

#include "../inc/push_swap.h"

void	ft_lstadd_front(t_list **lst, t_list *new)
{
	if (!lst || !new)
		return ;
	new->next = *lst;
	*lst = new;
}
