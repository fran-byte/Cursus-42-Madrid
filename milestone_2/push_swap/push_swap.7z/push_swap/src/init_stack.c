/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_stack.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/20 10:03:46 by frromero          #+#    #+#             */
/*   Updated: 2024/11/20 13:31:42 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void	init_stack_a(int argc, char **argv, t_list *new_node, t_list *lst)
{
	int i;
	int *num;


	num = (int *)malloc(sizeof(int));
	//if (!num)
	//	return (NULL);



	i = 0;
	while (++i < argc)
	{
		*num = ft_atoi(argv[i]);
		new_node = ft_lstnew(num);
		ft_lstadd_front(&lst, new_node);
	}
}
