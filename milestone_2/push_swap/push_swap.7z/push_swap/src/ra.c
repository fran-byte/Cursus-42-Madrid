/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ra.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 08:06:04 by frromero          #+#    #+#             */
/*   Updated: 2024/11/21 14:15:15 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void mov_ra(t_list *lst)
{

	t_list	*last;

	last = ft_lstlast(lst); // Obtenemos la dirección del últmo nodo
	lst = last;					// y nos posicionamos la cabecera de lst ahí

	// Recorremos hacia atrás la lista hasta el primer nodo (prev = NULL)
	while (lst->prev != NULL)
	{
		if (lst->next != NULL)
			lst->next->number = lst->number;
		// Transfiere el numero del nodo actual(lst) al siguiente(next)
		else
		{
			lst = lst->prev;
			write(1, "ra\n", 3);
		}
		// Mueve el puntero al nodo anterior (lst)=(prev)
		lst = lst->prev;
			write(1, "ra\n", 3);
	}
	// Una vez el puntero este en su posición correcta, es decir al principio de la lista
	// Falta pasar el número del último al primero
	//lst->number = last->number;
	//write(1, "ra\n", 3);
}
