/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pa.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/22 17:36:54 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 08:54:57 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* pa: Put the first element from stack b and places it on stack a.*/

#include "../inc/push_swap.h"

void pa(t_list **stack_a, t_list **stack_b)
{
	t_list *tmp;

	if (!stack_b || !*stack_b)
		return;
	tmp = *stack_b;
	*stack_b = tmp->next;
	if (*stack_b)
		(*stack_b)->prev = NULL;
	tmp->next = *stack_a;
	if (*stack_a)
		(*stack_a)->prev = tmp;
	*stack_a = tmp;
	write(1, "pa\n", 3);
}
