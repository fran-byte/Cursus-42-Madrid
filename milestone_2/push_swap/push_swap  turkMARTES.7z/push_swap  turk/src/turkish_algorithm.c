/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   turkish_algorithm.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/30 17:25:44 by frromero          #+#    #+#             */
/*   Updated: 2024/12/03 11:45:58 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

static void	rotate_by_dist(int dist, int mid, t_list **stack_a, t_list **stack_b)
{
	int i;
	t_list *current_a;
	t_list *current_b;

	current_a = *stack_a;
	current_b = *stack_b;
	i = 0;
	printf("\n i[%d] mid[%d] tamaño stack a: %d",i , mid, ft_lstsize(current_a));
	if (dist <= mid)
		while(i++ <= mid && ft_lstsize(current_a) > 3)
		{
			ra(current_a);
			printf("\n** 1º while i[%d] mid[%d]",i , mid);
		}
	else
		while(i++ > mid && ft_lstsize(current_a) > 3)
		{
			rra(current_a);
			printf("\n** 1º while (en el else) i[%d] mid[%d]",i , mid);
		}

	pb(&current_a, &current_b);
	printf("\n i[%d] mid[%d]",i , mid);
	printf("\nStack B\n--\n");
    ft_lstiter(*stack_b, print_numbers);
}

void turkish_algorithm(t_list **stack_a, t_list **stack_b)
{
	t_list *current_a;
	t_list *current_b;

	int dist;
	int mid = (ft_lstsize(*stack_a)) / 2;

	current_a = *stack_a;
	current_b = *stack_b;
	pb(stack_a, stack_b);
	pb(stack_a, stack_b);
	printf("current_a A\n--\n");
	ft_lstiter(*stack_a, print_numbers);
	printf("Stack B\n--\n");
	ft_lstiter(*stack_b, print_numbers);

	while (ft_lstsize(*stack_a) > 3)
	{

		dist = dist_node(&current_a, minimum(&current_a, -1));
		printf("\ndistancia al min: %d\n", dist);
		rotate_by_dist(dist, mid, stack_a, stack_b);

		printf("Stack A\n--\n");
        ft_lstiter(*stack_a, print_numbers);
		ft_lstiter(*stack_b, print_numbers);
		printf("tamaño de stack A: %d", ft_lstsize(*stack_a));
		return;
		assign_indices(current_a);//actualizar indices

	}
	/*sort_three(current_a);
	while (ft_lstsize(current_b) > 0)
	{
		pa(&current_a, &current_b);
		if ((*current_a->number) > (*current_a->next->number))
			sa(current_a);
	}*/









	//printf("___A___\n"); // No Push
	//ft_lstiter(current_a, print_numbers);





}
