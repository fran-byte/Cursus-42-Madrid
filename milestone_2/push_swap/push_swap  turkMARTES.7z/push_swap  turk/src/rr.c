/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rr.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 19:57:26 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 08:53:36 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*Reverse rotation (ra) and reverse rotation (rb).*/

#include "../inc/push_swap.h"

static void ra_rr(t_list *stack_a)
{
	t_list *current_a;
	int temp_a;

	if (!stack_a || !stack_a->next)
		return;
	temp_a = *stack_a->number;
	current_a = stack_a;
	while (current_a->next != NULL)
	{
		*current_a->number = *current_a->next->number;
		current_a = current_a->next;
	}
	*current_a->number = temp_a;
}

static void rb_rr(t_list *stack_b)
{
	t_list *current_b;
	int temp_b;

	if (!stack_b || !stack_b->next)
		return;
	temp_b = *stack_b->number;
	current_b = stack_b;
	while (current_b->next != NULL)
	{
		*current_b->number = *current_b->next->number;
		current_b = current_b->next;
	}
	*current_b->number = temp_b;
}

void rr(t_list **stack_a, t_list **stack_b)
{
	ra_rr(*stack_b);
	rb_rr(*stack_b);
	write(1, "rr\n", 3);
}
