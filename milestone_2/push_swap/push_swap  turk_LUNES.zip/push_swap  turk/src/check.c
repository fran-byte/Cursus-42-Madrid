/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/24 17:47:26 by frromero          #+#    #+#             */
/*   Updated: 2024/11/30 23:17:53 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*	We send it to check (check_input_two) if it is a single argument of numbers,
	send it to check (check_input) if there are multiple arguments > 2
	and we initialize stack_a */

#include "../inc/push_swap.h"

void	check(int argc, char **argv, t_list **stack)
{
	t_list *new_node = NULL;
	int	i;

	i = 0;
	if  (argc == 2)
	{
		while (check_with_one_arg(argc, argv)[i] != NULL)
			i++;
		init_stack_one_arg(i, check_with_one_arg(argc, argv), new_node, stack);
	}
	else
	{
		check_with_multiple_args(argc, argv);
		init_stack(argc, argv, new_node, stack);
	}
}
