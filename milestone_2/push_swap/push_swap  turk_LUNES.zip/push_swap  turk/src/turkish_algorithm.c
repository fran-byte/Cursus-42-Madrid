/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   turkish_algorithm.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/30 17:25:44 by frromero          #+#    #+#             */
/*   Updated: 2024/12/02 20:00:59 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void turkish_algorithm(t_list **stack_a, t_list **stack_b)
{
	t_list *current_a;
	t_list *current_b;
	int dist;

	current_a = *stack_a;
	current_b = *stack_b;
	dist = dist_node(&current_a, minimum(&current_a, -1));











	printf("___A___\n"); // No Push
	ft_lstiter(current_a, print_numbers);





}
