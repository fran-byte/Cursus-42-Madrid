/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pb.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/20 18:34:40 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 08:55:08 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* pb: Put the first element from stack a and places it on stack b.*/

#include "../inc/push_swap.h"

void del(void *number)
{
	free(number);
}

void pb(t_list **stack_a, t_list **stack_b)
{
	t_list *tmp;

	if (!stack_a || !*stack_a)
		return;
	tmp = *stack_a;
	*stack_a = tmp->next;
	if (*stack_a)
		(*stack_a)->prev = NULL;
	tmp->next = *stack_b;
	if (*stack_b)
		(*stack_b)->prev = tmp;
	*stack_b = tmp;
	write(1, "pb\n", 3);
}
