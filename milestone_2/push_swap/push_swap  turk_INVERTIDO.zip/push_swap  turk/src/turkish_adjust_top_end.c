/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   turkish_adjust_top_end.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/07 18:21:55 by frromero          #+#    #+#             */
/*   Updated: 2024/12/08 18:46:40 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

static int calculate_move(t_list *stack, t_list *node)
{
	int pos = 0;
	int total_size = ft_lstsize(stack);
	t_list *current = stack;

	while (current != NULL && current != node)
	{
		pos++;
		current = current->next;
	}
	if (pos <= total_size / 2)
		return pos;
	else
		return -(total_size - pos);
}

// Ejecuta movimientos en un solo stack para llevar un nodo al top
static void execute_single_stack_moves_a(t_list **stack, int moves)
{
	while (moves > 0)
	{
		ra(*stack);
		moves--;
	}
	while (moves < 0)
	{
		rra(*stack);
		moves++;
	}
}

static void execute_single_stack_moves_b(t_list **stack, int moves)
{
	while (moves > 0)
	{
		rb(*stack);
		moves--;
	}
	while (moves < 0)
	{
		rrb(*stack);
		moves++;
	}
}

static void execute_moves(t_list **stack_a, t_list **stack_b, int move_a, int move_b)
{
	while (move_a > 0 && move_b > 0)
	{
		rr(stack_a, stack_b); // Rotación simultánea hacia adelante
		move_a--;
		move_b--;
	}
	while (move_a < 0 && move_b < 0)
	{
		rrr(stack_a, stack_b); // Rotación simultánea hacia atrás
		move_a++;
		move_b++;
	}
	execute_single_stack_moves_a(stack_a, move_a);
	execute_single_stack_moves_b(stack_b, move_b);
}

// Lleva tanto el nodo de A como su target en B al top usando los movimientos más eficientes
void move_nodes_to_top_end(t_list **stack_a, t_list **stack_b, t_list *target_a, t_list *node_b)
{
	int move_a;
	int move_b;

	move_a = calculate_move(*stack_a, node_b);
	move_b = calculate_move(*stack_b, target_a);
	execute_moves(stack_a, stack_b, move_a, move_b);
}
