/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pa.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/22 17:36:54 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 00:25:00 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* pa: Put the first element from stack b and places it on stack a.*/

#include "../inc/push_swap.h"

void pa(t_list **lst, t_list **lstb)
{
	t_list *tmp;

	if (!lstb || !*lstb) // Verificar si hay nodos en lstb
		return;

	tmp = *lstb;	   // Almacenar el nodo a mover
	*lstb = tmp->next; // Actualizar la cabeza de lstb
	if (*lstb)		   // Si hay más nodos, desvincular el nodo movido
		(*lstb)->prev = NULL;

	// Añadir el nodo movido al frente de lst
	tmp->next = *lst;
	if (*lst) // Si lst no está vacío, actualizar prev del antiguo primer nodo
		(*lst)->prev = tmp;
	*lst = tmp; // Actualizar la cabeza de lst

	write(1, "pa\n", 3);
}
