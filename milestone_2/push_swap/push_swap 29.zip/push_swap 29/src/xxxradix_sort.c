/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   xxxradix_sort.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/24 18:49:36 by frromero          #+#    #+#             */
/*   Updated: 2024/11/27 18:20:16 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void radix_sort(t_list **stack_a, t_list **stack_b)
{
	t_list *current_a = *stack_a; // Copia del puntero a stack_a
	int bit = 0;				  // Variable para controlar si aún hay nodos con bit 0
	int i;
	int size;
	int move_bit;

	move_bit = 0;

	i = 0;

	printf("\nStack a (**INICIAL**):\n");
	ft_lstiter(*stack_a, print_numbers);
	if (*stack_a == NULL)
		return;

	while (is_sorted(*stack_a) != 1)
	{
		size = ft_lstsize(*stack_a);
		while (bit == 0 || i == 0)
		{
			current_a = *stack_a;
			while ((bit == 0 || i <= size))
			{
				if (((*(current_a->number) >> move_bit) & 1) == 0)// Si el bit más bajo es 0
				{
					pb(stack_a, stack_b);
					bit = 0;
					size--;
				}
				ra(*stack_a);
				bit = 1;
				i++;
				current_a = *stack_a;
			}
		}

		printf("\nStack a (final):\n");
		ft_lstiter(*stack_a, print_numbers);

		printf("\nStack b (final):\n");
		ft_lstiter(*stack_b, print_numbers);
		size = ft_lstsize(*stack_b);

		while (*stack_b)
			pb(stack_b, stack_a);

		printf("\nStack a ********** DESPUES DE HACER todos los PA:\n");
		ft_lstiter(*stack_a, print_numbers);

		printf("\nStack b ********** DESPUES DE HACER todos los PA:\n");
		ft_lstiter(*stack_b, print_numbers);

		size = ft_lstsize(*stack_a);

		move_bit++;
		printf("\nsize = %d    -   i = %d    -   bit = %d   -   move_bit = %d\n", size, i, bit, move_bit);
		i = 0;
	}
}
/*
void radix_sort(t_list **stack_a, t_list **stack_b)
{
	int move_bit;

	move_bit = 0;
	while(is_sorted(*stack_a) != 1)
	{
		start_radix_sort(stack_a, stack_b, move_bit);
		move_bit++;
		printf("\nStack a (TESTEO):\n");
		ft_lstiter(*stack_a, print_numbers);
	}
}*/
