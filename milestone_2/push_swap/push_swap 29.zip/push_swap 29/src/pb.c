/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pb.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/20 18:34:40 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 00:25:09 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* pb: Put the first element from stack a and places it on stack b.*/

#include "../inc/push_swap.h"

void del(void *number)
{
	free(number);
}

void pb(t_list **lst, t_list **lstb)
{
	t_list *tmp;

	if (!lst || !*lst) // Verificar si hay nodos en lst
		return;

	tmp = *lst;		  // Almacenar el nodo a mover
	*lst = tmp->next; // Actualizar la cabeza de lst
	if (*lst)		  // Si hay más nodos, desvincular el nodo movido
		(*lst)->prev = NULL;

	// Añadir el nodo movido al frente de lstb
	tmp->next = *lstb;
	if (*lstb) // Si lstb no está vacío, actualizar prev del antiguo primer nodo
		(*lstb)->prev = tmp;
	*lstb = tmp; // Actualizar la cabeza de lstb

	write(1, "pb\n", 3);
}
