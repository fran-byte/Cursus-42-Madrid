/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   radix_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/24 18:49:36 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 00:42:12 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void radix_sort_multiple(t_list **stack_a, t_list **stack_b)
{
	t_list *new_node_a = NULL;
	t_list *current_a = *stack_a;
	int bit = 0;
	int size;
	int move_bit;
	int count_ra = 0;
	int original_size = ft_lstsize(*stack_a);
	move_bit = 0;

	ft_lstiter(*stack_a, print_numbers);  // No Push
	printf("stack  A Inicial\n--\n\n\n"); // No Push

	if (*stack_a == NULL)
		return;

	while (is_sorted(*stack_a) != 1)
	{
		size = ft_lstsize(*stack_a);
		current_a = *stack_a;
		while ((bit == 0 || count_ra <= size))
		{
			// *************************************************************************************************************
			// ENCONTRADO BUG ***
			// Se modoificó PA y PB ya no se destruyen ....AL DESTRUIR TODOS LOS NODOS DE A al pasarlos a B, nos quedamos sin referencia de la lista A
			// y no puede regresar dando un segmentation fault, solución:
			// 1 o se parchea radix_sort_multiple() intentando crear un nodo con el primer elemento a pasar de B
			// 2 o depurar las funciones PA y PB y en lugar de crear y destruir nodos, modificar direcciones de memoria.
			//*************************************************************************************************************** /
			if (*stack_a == NULL)
			{
				printf("\nSTACK A Es NULL\n"); // No Push
			}

			if ((((*(current_a->number)) >> move_bit) & 1) == 0)
			{
				pb(stack_a, stack_b);
				if (*stack_a == NULL)
				{
					while (*stack_b)
					{
						pa(stack_a, stack_b);
					}
					if (is_sorted(*stack_a) == 1)
					{
						printf("\nSTACK - ORDENADO:\n");	 // No Push
						ft_lstiter(*stack_a, print_numbers); // No Push
						return;
					}
				}

				bit = 0;
				size--;
				printf("\nSTACK A (pb)  Stack A -----> Stack B\n"); // No Push
				ft_lstiter(*stack_a, print_numbers);				// No Push

				printf("\nSTACK B (pb)  Stack A -----> Stack B\n"); // No Push
				ft_lstiter(*stack_b, print_numbers);				// No Push
			}
			else
			{
				if (ft_lstsize(*stack_a) == 1)
				{
					bit = 1;
					count_ra++;
				}
				else
				{
					ra(*stack_a);
					printf("\nSTACK A despues del ra anterior\n"); // No Push
					ft_lstiter(*stack_a, print_numbers);
					bit = 1;
					count_ra++;
				}
			}
			current_a = *stack_a;
			printf("\n*********  VARIABLES **********     bit = %d count_ra = %d size = %d\n", bit, count_ra, size);

			if (original_size == ft_lstsize(*stack_a) && is_sorted(*stack_a) == 1)
			{
				printf("\nSTACK - ORDENADO:\n");	 // No Push
				ft_lstiter(*stack_a, print_numbers); // No Push
				return;
			}
		}

		while (*stack_b)
		{
			pa(stack_a, stack_b);

			printf("\nSTACK A (pa)  Stack B -----> Stack A\n"); // No Push
			ft_lstiter(*stack_a, print_numbers);				// No Push

			printf("\nSTACK B (pa)  Stack B -----> Stack A\n"); // No Push
			ft_lstiter(*stack_b, print_numbers);
		}
		if (is_sorted(*stack_a) == 1)
		{
			printf("\nSTACK - ORDENADO:\n");	 // No Push
			ft_lstiter(*stack_a, print_numbers); // No Push
			return;
		}

		size = ft_lstsize(*stack_a);
		move_bit++;
		printf("\n**********************    DESPLAZAMIENTO DE BITS (%d) *************\n", move_bit);
		count_ra = 0;
	}
	printf("\nSTACK - ORDENADO:\n");	 // No Push
	ft_lstiter(*stack_a, print_numbers); // No Push
	return;
}

void radix_sort(t_list **stack_a, t_list **stack_b)
{

	if (is_sorted(*stack_a) == 1)
		return;
	if (ft_lstsize(*stack_a) == 2)
	{
		sa(*stack_a);
		return;
	}
	if (ft_lstsize(*stack_a) == 3)
	{
		sort_up_to_five(stack_a, stack_b);
		return;
	}
	radix_sort_multiple(stack_a, stack_b);
}
