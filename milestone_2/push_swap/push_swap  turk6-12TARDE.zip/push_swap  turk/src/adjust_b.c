/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   adjust_b.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/06 15:54:23 by frromero          #+#    #+#             */
/*   Updated: 2024/12/06 18:00:57 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void target_b(t_list *stack_a, t_list *stack_b)
{
	t_list *current_a;
	t_list *current_b;
	int min;
	int max;

	current_a = stack_a;
	current_b = stack_b;
	min = minimum(&current_b, -1);
	max = maximum(&current_b, -1);
	if (*current_a->number < min) // Si number es menor que el mínimo de B
		current_a->target = max;// Nuestro objetivo será el numero mayor de B
	else // nuestro objetivo será el mas pequeño de B pero que debe ser mas grande
	{	 // que nuestro número de A
		if(*current_a->number > min && )
	}
}

/*
void	adjiust_stack_b(t_list **stack_a, t_list **stack_b)
{
	t_list **current_a;
	t_list **current_b;
}
*/
3   5
	2
	1
