/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   radix_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/24 18:49:36 by frromero          #+#    #+#             */
/*   Updated: 2024/11/28 12:00:53 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void radix_sort(t_list **stack_a, t_list **stack_b)
{
	t_list *current_a = *stack_a;
	int bit = 0;

	int size;
	int move_bit;
	int count_ra = 0;

	move_bit = 0;

	ft_lstiter(*stack_a, print_numbers);  // No Push
	printf("stack  A Inicial\n--\n\n\n"); // No Push

	if (*stack_a == NULL)
		return;

	while (is_sorted(*stack_a) != 1)
	{
		size = ft_lstsize(*stack_a);
		current_a = *stack_a;
		while ((bit == 0 || count_ra <= size))
		{
			if ((((*(current_a->number)) >> move_bit) & 1) == 0)
			{
				pb(stack_a, stack_b);
				bit = 0;
				size--;
				printf("\nSTACK A (pb)  Stack A -----> Stack B\n"); // No Push
				ft_lstiter(*stack_a, print_numbers);				// No Push

				printf("\nSTACK B\n");				 // No Push
				ft_lstiter(*stack_b, print_numbers); // No Push
			}
			else
			{
				ra(*stack_a);
				bit = 1;
				count_ra++;

			}
			current_a = *stack_a;
			printf("\n*********  VARIABLES **********\n");
			printf("\nbit = %d:\n",bit);
			printf("\ncount_ra = %d:\n",count_ra);
			printf("\nsize = %d:\n",size);
		}

		while (*stack_b)
		{
			pa(stack_a, stack_b);
			// printf("\nSTACK a\n");				 // No Push
			// ft_lstiter(*stack_a, print_numbers);// No Push

			// printf("\nSTACK b\n");				 // No Push
			// ft_lstiter(*stack_b, print_numbers); // No Push
		}
		printf("\nSTACK A (pa)  Stack B -----> Stack A\n"); // No Push
		ft_lstiter(*stack_a, print_numbers);				// No Push

		printf("\nSTACK b\n");				 // No Push
		ft_lstiter(*stack_b, print_numbers); // No Push

		size = ft_lstsize(*stack_a);
		move_bit++;
		count_ra = 0;
	}
	printf("\nSTACK - ORDENADO:\n");	 // No Push
	ft_lstiter(*stack_a, print_numbers); // No Push
}
