/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_one_arg.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/19 00:07:51 by frromero          #+#    #+#             */
/*   Updated: 2024/12/10 00:22:01 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
   This file validates input for the `push_swap` program.
   - `inputs_are_digits`: Ensures inputs are valid numbers or signs.
   - `inputs_has_dup`: Checks for duplicate numbers.
   - `int_check_limit`: Validates integer range for all inputs.
   - `check_input`: Main function coordinating all validations.
*/

#include "../inc/push_swap.h"

void	free_arguments(char **numbers)
{
	int	i;

	if (!numbers)
		return ;
	i = 0;
	while (numbers[i] != NULL)
	{
		free(numbers[i]);
		i++;
	}
	free(numbers);
}

static void inputs_are_digits(int gc, char **gv)
{
	int i;
	int j;

	i = -1;
	while (++i < gc)
	{
		j = 0;
		while (gv[i][j] != '\0')
		{
			if (!((gv[i][j] >= '0' && gv[i][j] <= '9') ||
				(gv[i][j] == '-' || gv[i][j] == '+')))
			{
				free_arguments(gv);
				program_error();
			}
			j++;
		}
	}
}

static void inputs_has_dup(int gc, char **gv)
{
	int i;
	int j;

	i = 0;
	while (i < gc)
	{
		j = i + 1;
		while (j < gc)
		{
			if (ft_strcmp(gv[i], gv[j]) == 0)
			{
				free_arguments(gv);
				program_error();
			}
			j++;
		}
		i++;
	}
}

static void int_check_limit(int gc, char **gv)
{
	int i;

	i = -1;
	while (++i < gc)
		ft_atoi(gv[i]); // NECESITA LIBERAR EL RESTO ESTA YA
}

char **check_with_one_arg(int gc, char **gv)
{
	char	**sp_argv;
	char	c;
	int	i;

	i = 0;
	c = ' ';
	if  (gc == 2)
	{
		sp_argv = one_argument(gv[1], c);
		while (sp_argv[i] != NULL)
			i++;
		inputs_are_digits(i, sp_argv);
		inputs_has_dup(i, sp_argv);
		int_check_limit(i, sp_argv);
		return(sp_argv);
	}
	return(0);
}
