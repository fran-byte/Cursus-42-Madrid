/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_utils_libft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/08 10:34:48 by frromero          #+#    #+#             */
/*   Updated: 2024/12/10 00:22:40 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* libft:   ft_atoi - ft_calloc - ft_strlen - ft_memset */

#include "../inc/push_swap.h"

static int	sign_and_space(const char *str, int *sign)
{
	int	i;

	i = 0;
	while ((str[i] >= 9 && str[i] <= 13) || str[i] == ' ')
		i++;
	if ((str[i] == '-' || str[i] == '+') && (str[i + 1] == '-'
			|| str[i + 1] == '+'))
		program_error();
	if (str[i] == '+')
		i++;
	else if (str[i] == '-')
	{
		*sign = -1;
		i++;
	}
	return (i);
}

int	ft_atoi(const char *str)
{
	int	sign;
	int	nb;
	int	i;

	sign = 1;
	nb = 0;
	i = sign_and_space(str, &sign);
	while (str[i] >= '0' && str[i] <= '9')
	{
		if (nb > INT_MAX / 10 || (nb == INT_MAX / 10
				&& (str[i] - '0') > INT_MAX % 10))
			{
				//NECESITA LIBERAR
				program_error();
			}
		nb = nb * 10 + (str[i] - '0');
		i++;
	}
	return (nb * sign);
}

void	*ft_calloc(size_t count, size_t size)
{
	void	*ptr;

	ptr = malloc(count * size);
	if (ptr == NULL)
		return (NULL);
	ft_memset(ptr, 0, count * size);
	return (ptr);
}

size_t	ft_strlen(const char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

void	*ft_memset(void *s, int c, size_t n)
{
	size_t				i;
	unsigned char		*buf;

	i = 0;
	buf = (unsigned char *)s;
	while (i < n)
	{
		buf[i] = c;
		i++;
	}
	return (buf);
}
