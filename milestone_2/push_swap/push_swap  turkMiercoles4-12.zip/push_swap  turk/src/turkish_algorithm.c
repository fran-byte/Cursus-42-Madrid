/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   turkish_algorithm.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/30 17:25:44 by frromero          #+#    #+#             */
/*   Updated: 2024/12/04 19:31:06 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

static void	rotate_by_dist(int dist, t_list **stack_a, t_list **stack_b)
{
	int i;
	t_list **current_a;
	t_list **current_b;

	current_a = stack_a;
	current_b = stack_b;
	i = 1;
	int mid = (ft_lstsize(*stack_a)) / 2;

	printf("\n i[%d] mid[%d] tamaño stack a: %d   rotate_by_dist",i , mid, ft_lstsize(*current_a));
	if (dist <= mid)
		while(dist <= mid && ft_lstsize(*current_a) > 3)
		{
			ra(*current_a);
			printf("\n ** 1º while (IF) i[%d] mid[%d]   rotate_by_dist",i , mid);
			dist++;
		}
	else
		while(dist > mid && ft_lstsize(*current_a) > 3)
		{
			rra(*current_a);
			printf("\n ** 1º while (ELSE) i[%d] mid[%d]  rotate_by_dist",i , mid);
			dist--;
		}

	pb(current_a, current_b);

	printf("\nrotate_by_dist  i[%d] mid[%d]",i , mid);
	printf("\nrotate_by_dist Stack B\n--\n");
    ft_lstiter(*current_b, print_numbers);
}

void turkish_algorithm(t_list **stack_a, t_list **stack_b)
{
	t_list **current_a;
	t_list **current_b;

	int dist;

	current_a = stack_a;
	current_b = stack_b;
	pb(stack_a, stack_b);
	pb(stack_a, stack_b);

	printf(" current_a A   turkish_algorithm\n--\n");
	ft_lstiter(*stack_a, print_numbers);
	printf(" Stack B   turkish_algorithm\n--\n");
	ft_lstiter(*stack_b, print_numbers);

	if (is_sorted(*stack_b) == 1) // "Desordenar B"
		sb(*stack_b);

	printf(" Stack B   turkish_algorithm\n--\n");
	ft_lstiter(*stack_b, print_numbers);

	while (ft_lstsize(*stack_a) > 3)
	{

		dist = dist_node(current_a, minimum(current_a, -1));
		printf("\n distancia al min: %d   turkish_algorithm\n", dist);
		rotate_by_dist(dist,  stack_a, stack_b);

		printf("\n Stack A   turkish_algorithm\n--\n");
        ft_lstiter(*stack_a, print_numbers);
		ft_lstiter(*stack_b, print_numbers);
		printf("\n While 1º funcion tamaño de stack A: %d   turkish_algorithm\n", ft_lstsize(*stack_a));

		assign_indices(*current_a);//actualizar indices

	}
	sort_three(*current_a);
	while (ft_lstsize(*current_b) > 0)
	{
		pa(current_a, current_b);
		//if ((current_a->number) > (current_a->next->number))
			//sa(*current_a);
	}









	//printf("___A___\n"); // No Push
	//ft_lstiter(current_a, print_numbers);





}
