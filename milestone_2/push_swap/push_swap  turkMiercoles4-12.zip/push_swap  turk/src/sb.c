/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sb.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/20 18:34:40 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 08:46:31 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* Swap (sb) swaps the values of the first two nodes in the list.
   The values of the first and second nodes are exchanged.*/

#include "../inc/push_swap.h"

void sb(t_list *stack_b)
{
	t_list *second_b;
	int *temp_b;

	if (!stack_b || !stack_b->next)
		return ;
	second_b = stack_b->next;
	temp_b = stack_b->number;
	stack_b->number = second_b->number;
	second_b->number = temp_b;
	write(1, "sb\n", 3);
}
