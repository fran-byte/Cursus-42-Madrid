/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 22:49:16 by frromero          #+#    #+#             */
/*   Updated: 2024/12/03 10:54:46 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
#define PUSH_SWAP_H

#include <unistd.h>
#include <stdlib.h>
#include <limits.h>
#include <stdio.h>	// borrar * * * * ************************************
#include <string.h> // borrar * * * * ************************************

typedef struct s_list
{
	int *number;
	int index;
	struct s_list *prev;
	struct s_list *next;
}t_list;

int	ft_lstsize(t_list *lst);
int	ft_atoi(const char *str);
int	is_sorted(t_list *lst);
int	minimum(t_list **stack, int number);
int dist_node(t_list **stack, int index);
size_t	ft_strlen(const char *str);
t_list *init_stack_one_arg(int argc, char **argv, t_list *new_node, t_list **lst);
t_list	*init_stack(int argc, char **argv, t_list *new_node, t_list **stack);
t_list	*ft_lstlast(t_list *lst);
t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *));
t_list	*ft_lstnew(int *number);
char	**check_with_one_arg(int gc, char **gv);
char	**one_argument(char *s, char c);
void 	assign_indices(t_list *stack);
//void	index_stack(t_list **stack);
void	sort_three(t_list *stack_a);
void	sort_four(t_list *stack_a, t_list *stack_b);
void	sort_five(t_list *stack_a, t_list *stack_b);
void	check_with_multiple_args(int argc, char **argv);
void	algorithm(t_list **stack_a, t_list **stack_b);
void	check(int argc, char **argv, t_list **stack_a);
void	program_error();
void	program_exit();
void	ft_lstadd_back(t_list **lst, t_list *new);
void	ft_lstadd_front(t_list **lst, t_list *new);
void	ft_lstclear(t_list **lst, void (*del)(void*));
void	ft_lstdelone(t_list *lst, void (*del)(void*));
void	ft_lstiter(t_list *lst, void (*f)(void *));
void	sa(t_list *stack_a);
void	ra(t_list *stack_a);
void	rra(t_list *stack_a);
void	sb(t_list *stack_b);
void	rb(t_list *stack_b);
void	rrb(t_list *stack_b);
void	rrr(t_list **stack_a, t_list **stack_b);
void	rr(t_list **stack_a, t_list **stack_b);
void	ss(t_list *stack_a, t_list *stack_b);
void	pb(t_list **stack_a, t_list **stack_b);
void	pa(t_list **stack_a, t_list **stack_b);
void	del(void *number);
void	*ft_calloc(size_t count, size_t size);
void	*ft_memset(void *s, int c, size_t n);
void	turkish_algorithm(t_list **stack_a, t_list **stack_b);
void	print_numbers(void *number);  // BORRAR esta función imprimiremos con write()

#endif
