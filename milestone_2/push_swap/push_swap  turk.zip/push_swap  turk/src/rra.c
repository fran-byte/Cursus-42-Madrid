/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rra.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 16:57:24 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 08:52:10 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*Reverse rotation (rra) moves the value of the last node to the first position,
  and shifts all other nodes values one step forward.*/

#include "../inc/push_swap.h"

void rra(t_list *stack_a)
{
	t_list *current_a;
	t_list *last_stack_a;
	int temp_a;

	if (!stack_a || !stack_a->next)
		return;
	last_stack_a = ft_lstlast(stack_a);
	temp_a = *last_stack_a->number;
	current_a = last_stack_a->prev;
	while (current_a != NULL)
	{
		*current_a->next->number = *current_a->number;
		current_a = current_a->prev;
	}
	*stack_a->number = temp_a;
	write(1, "rra\n", 4);
}
