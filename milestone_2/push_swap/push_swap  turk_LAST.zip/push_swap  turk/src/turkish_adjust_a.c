/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   turkish_adjust_a.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/07 16:56:47 by frromero          #+#    #+#             */
/*   Updated: 2024/12/08 16:31:55 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

t_list *find_smallest_in_a(t_list *stack_a)
{
	t_list *current = stack_a;
	t_list *target = NULL;
	int smallest = INT_MAX;

	while (current != NULL) // Buscar el menor número en A
	{
		if (*(current->number) < smallest)
		{
			smallest = *(current->number);
			target = current;
		}
		current = current->next;
	}
	return (target);
}

t_list *find_target_a(t_list *b_node, t_list *stack_a)
{
    t_list *current = stack_a;
    t_list *target = NULL;
    int smallest_larger = INT_MAX; // El número más pequeño mayor que b_node->number

    // Buscar el nodo objetivo en A (mayor que b_node->number pero menor que cualquier otro número en A)
    while (current != NULL)
    {
        if (*(current->number) > *(b_node->number) && *(current->number) < smallest_larger)
        {
            smallest_larger = *(current->number); // Actualiza el valor de largest_smaller
            target = current;                      // Asigna el nodo como el nuevo target
        }
        current = current->next;
    }

    // Si no se encontró ningún número mayor, usar la función para encontrar el menor número en A
    if (target == NULL)
    {
        target = find_smallest_in_a(stack_a);
    }

    return target;
}



static int calculate_cost_for_a(t_list *node, t_list *stack_a, t_list *stack_b)
{
    int cost_a;
    int cost_b;
	int total_b_size;
	int total_a_size;
	t_list *target;
	t_list *current;

	cost_a = 0;
	cost_b = 0;
    current = stack_a;
    while (current != NULL && current != node)// Calcular el costo de mover el nodo a la cima de A (considerando ra y rra)
    {
        cost_a++;
        current = current->next;
    }
    total_a_size = ft_lstsize(stack_a);// Decidir si usar ra o rra
    if (cost_a > total_a_size / 2)
        cost_a = total_a_size - cost_a; // rra
    target = find_target_a(node, stack_b);// Calcular el costo de mover el target a la cima de B
    current = stack_b;
    while (current != NULL && current != target)
    {
        cost_b++;
        current = current->next;
    }
    total_b_size = ft_lstsize(stack_b);
    if (cost_b > total_b_size / 2)// Decidir si usar rb o rrb
        cost_b = total_b_size - cost_b; // rrb
    return cost_a + cost_b; // El costo total es la suma de los costos de A y B
}
t_list *find_lowest_cost_node_a(t_list *stack_a, t_list *stack_b)
{
    t_list *current;
    t_list *lowest_cost_node;
    int lowest_cost;
    int cost;

    lowest_cost = INT_MAX;
    current = stack_a;
    lowest_cost_node = NULL;

    while (current != NULL)
    {
        cost = calculate_cost_for_a(current, stack_a, stack_b);


        // Actualizar solo si el costo es estrictamente menor
        if (cost < lowest_cost)
        {
            lowest_cost = cost;
            lowest_cost_node = current;
        }
        // Si los costos son iguales, priorizamos el primer nodo evaluado
        else if (cost == lowest_cost && lowest_cost_node == NULL)
        {
            lowest_cost_node = current;
        }

        current = current->next;
    }
    return (lowest_cost_node);
}


