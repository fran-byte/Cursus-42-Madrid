/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   turkish_adjust_top_end.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/07 18:21:55 by frromero          #+#    #+#             */
/*   Updated: 2024/12/08 17:57:07 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

// Calcula los movimientos necesarios para llevar un nodo al top del stack
static int calculate_move(t_list *stack, t_list *node)
{
	int pos = 0;
	int total_size = ft_lstsize(stack);
	t_list *current = stack;

	// Encontrar la posición del nodo
	while (current != NULL && current != node)
	{
		pos++;
		current = current->next;
	}

	// Depurar el valor de la posición

	// Decidir el movimiento más eficiente
	if (pos <= total_size / 2)
	{
		return pos; // Movimientos hacia adelante (ra/rb)
	}
	else
	{
		return -(total_size - pos); // Movimientos hacia atrás (rra/rrb)
	}
}

// Ejecuta movimientos en un solo stack para llevar un nodo al top
static void execute_single_stack_moves_a(t_list **stack, int moves)
{
	while (moves > 0)
	{
		ra(*stack); // Rotación hacia adelante (ra)
		moves--;
	}
	while (moves < 0)
	{
		rra(*stack); // Rotación hacia atrás (rra)
		moves++;
	}
}

static void execute_single_stack_moves_b(t_list **stack, int moves)
{
	while (moves > 0)
	{
		rb(*stack); // Rotación hacia adelante (rb)
		moves--;
	}
	while (moves < 0)
	{
		rrb(*stack); // Rotación hacia atrás (rrb)
		moves++;
	}
}

// Ejecuta los movimientos necesarios para alinear dos nodos en A y B simultáneamente
static void execute_moves(t_list **stack_a, t_list **stack_b, int move_a, int move_b)
{
	// Ejecutar movimientos combinados (rr o rrr) si aplican
	while (move_a > 0 && move_b > 0)
	{
		rr(stack_a, stack_b); // Rotación simultánea hacia adelante
		move_a--;
		move_b--;
	}
	while (move_a < 0 && move_b < 0)
	{
		rrr(stack_a, stack_b); // Rotación simultánea hacia atrás
		move_a++;
		move_b++;
	}

	// Ejecutar movimientos restantes para A
	execute_single_stack_moves_a(stack_a, move_a);

	// Ejecutar movimientos restantes para B
	execute_single_stack_moves_b(stack_b, move_b);
}

// Lleva tanto el nodo de A como su target en B al top usando los movimientos más eficientes
void move_nodes_to_top_end(t_list **stack_a, t_list **stack_b, t_list *target_a, t_list *node_b)
{
	int move_a;
	int move_b;

	// Calcular los movimientos necesarios para subir node_a y target_b al tope
	move_a = calculate_move(*stack_a, node_b);
	move_b = calculate_move(*stack_b, target_a);

	// Depuración antes de ejecutar los movimientos

	// Ejecutar los movimientos
	execute_moves(stack_a, stack_b, move_a, move_b);
}
