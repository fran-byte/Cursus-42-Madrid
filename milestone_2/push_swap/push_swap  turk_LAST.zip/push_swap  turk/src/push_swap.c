/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 20:31:22 by frromero          #+#    #+#             */
/*   Updated: 2024/12/08 18:04:44 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* Passing a pointer to pointer (e.g., pa(&stack_a, &stack_b);) allows modifying
   the stack's head in the caller's scope.
   Passing just the pointer (e.g., sa(stack_a);) modifies the stack's content
   but not the pointer itself.

 - Pointer to pointer:	pa(&stack_a, &stack_b);  pb(&stack_a, &stack_b);
						rrr(&stack_a, &stack_b); rr(&stack_a, &stack_b);
 - Pointer: sa(stack_a); sb(stack_b);
  ra(stack_a); rb(stack_b); ss(stack_a, stack_b); rra(stack_a); rrb(stack_b); */

#include "../inc/push_swap.h"

int main(int argc, char **argv)
{
	t_list *stack_a = NULL;
	t_list *stack_b = NULL;

	check(argc, argv, &stack_a);
	assign_indices(stack_a);
	algorithm(&stack_a, &stack_b);

	printf("\n\n* MAIN\nA\n--\n");
	ft_lstiter(stack_a, print_numbers);
	printf("\nB\n--\n");
	if(is_sorted(stack_a) == 1)
		printf("\n ** * * ORDENADO * * **\n");
	ft_lstiter(stack_b, print_numbers);
	ft_lstclear(&stack_a, del);
	ft_lstclear(&stack_b, del);
}
