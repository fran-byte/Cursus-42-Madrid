/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   turkish_algorithm.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/30 17:25:44 by frromero          #+#    #+#             */
/*   Updated: 2024/11/30 19:07:45 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void turkish_algorithm(t_list **stack_a, t_list **stack_b)
{
	t_list *current_a;
	t_list *current_b;

	current_a = *stack_a;
	current_b = *stack_b;

	//pb(&current_a, &current_b);
	//pb(&current_a, &current_b);
	printf("___A___\n"); // No Push
	ft_lstiter(current_a, print_numbers);  // No Push
	//ft_lstiter(*stack_b, print_numbers);  // No Push


	//while (is_sorted(*stack_a) != 1)
	//	{
	//	}


}
