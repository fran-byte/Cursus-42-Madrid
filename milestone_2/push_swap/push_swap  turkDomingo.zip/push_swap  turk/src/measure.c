/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   measure.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/30 14:15:37 by frromero          #+#    #+#             */
/*   Updated: 2024/12/01 17:16:22 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void assign_indices(t_list *stack)
{
	t_list *current;
	t_list *temp;
	int index;

	current = stack;
	while (current)
	{
		index = 0;
		temp = stack;
		while (temp)
		{
			if (*temp->number < *current->number)
				index++;
			temp = temp->next;
		}
		current->index = index;
		printf("Valor: %d, Índice asignado: %d\n", *current->number, current->index);
		current = current->next;
	}
}
int minimum(t_list **stack, int number)
{
    t_list *current;
    int min_index;

    if (!(*stack))
    {
        printf("Error: La lista está vacía.\n");
        return (-1);
    }

    current = *stack;
    min_index = current->index;

    printf("Inicio de búsqueda del mínimo. Ignorando índice: %d\n", number);
    printf("Valor inicial del mínimo: %d\n", min_index);

    while (current->next)
    {
        current = current->next;

        printf("Analizando índice: %d (mínimo actual: %d)\n", current->index, min_index);

        if ((current->index < min_index) && current->index != number)
        {
            min_index = current->index;
            printf("Nuevo mínimo encontrado: %d\n", min_index);
        }
    }

    printf("Mínimo final encontrado: %d\n", min_index);
    return (min_index);
}


int dist_node(t_list **stack, int index)
{
	t_list *current;
	int dist_node;

	dist_node = 0;
	current = *stack;
	while (current)
	{
		if (current->index == index)
			break;
		dist_node++;
		current = current->next;
	}
	return (dist_node);
}
