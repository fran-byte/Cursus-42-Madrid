/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sa.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/20 18:34:40 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 08:52:31 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* Swap (sa) swaps the values of the first two nodes in the list.
   The values of the first and second nodes are exchanged.*/

#include "../inc/push_swap.h"

void sa(t_list *stack_a)
{
	t_list *second_a;
	int *temp_a;

	if (!stack_a || !stack_a->next)
		return ;
	second_a = stack_a->next;
	temp_a = stack_a->number;
	stack_a->number = second_a->number;
	second_a->number = temp_a;
	write(1, "sa\n", 3);
}
