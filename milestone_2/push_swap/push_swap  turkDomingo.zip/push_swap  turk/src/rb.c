/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rb.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 08:06:04 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 08:53:56 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* Rotation (rb) moves the value of the first node to the last position,
   and shifts all other nodes' values one step backward.*/

#include "../inc/push_swap.h"

void rb(t_list *stack_b)
{
	t_list *current_b;
	int temp_b;

	if (!stack_b || !stack_b->next)
		return;
	temp_b = *stack_b->number;
	current_b = stack_b;
	while (current_b->next != NULL)
	{
		*current_b->number = *current_b->next->number;
		current_b = current_b->next;
	}
	*current_b->number = temp_b;
	write(1, "rb\n", 3);
}
