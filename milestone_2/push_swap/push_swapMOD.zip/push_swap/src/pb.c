/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pb.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/20 18:34:40 by frromero          #+#    #+#             */
/*   Updated: 2024/11/23 18:58:01 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* pb: Put the first element from stack a and places it on stack b.*/

#include "../inc/push_swap.h"

void del(void *number)
{
	free(number);
}

void pb(t_list **lst, t_list **lstb)
{
	t_list *new_node_b = NULL;
	t_list *stackb;
	t_list *tmp;
	int temp;

	if (!lst || !*lst)
		return;
	stackb = init_stack_b(new_node_b ,lstb);
	stackb = *lstb;
	temp = *(*lst)->number;
	*stackb->number = temp;
	write(1, "pb\n", 3);
	tmp = (*lst)->next;
	if (tmp != NULL)
		tmp->prev = NULL;
	ft_lstdelone(*lst, del);
	*lst = tmp;
}
