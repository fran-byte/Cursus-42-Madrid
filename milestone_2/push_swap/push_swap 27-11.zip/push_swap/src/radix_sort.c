/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   radix_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/24 18:49:36 by frromero          #+#    #+#             */
/*   Updated: 2024/11/27 00:04:40 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void radix_sort(t_list **stack_a, t_list **stack_b)
{
    t_list *current_a = *stack_a;  // Copia del puntero a stack_a

    printf("\nStack a (inicio):\n");
    ft_lstiter(*stack_a, print_numbers);

    if (*stack_a == NULL)
        return;

    // Mientras haya nodos en stack_a
    int has_even_bit = 0; // Variable para controlar si aún hay nodos con bit 0
    while (has_even_bit == 0)
    {
        printf("Recorriendo stack_a:\n");
        has_even_bit = 1; // Inicialmente asumimos que no hay más bits 0

        current_a = *stack_a; // Volvemos a la cabeza de stack_a en cada iteración

        while (current_a != NULL)
        {
            printf("Procesando nodo con valor: %d\n", *(current_a->number));

            if (((*(current_a->number)) & 1) == 0) // Si el bit más bajo es 0
            {
                printf("Moviendo nodo a stack_b: %d (bit más bajo es 0)\n", *(current_a->number));
                pb(stack_a, stack_b);                  // Mueve el nodo a stack_b
                has_even_bit = 0; // Hemos encontrado un bit 0, seguimos en el bucle
                break; // Salimos del while interno para evitar seguir procesando los demás nodos
            }
            else
            {
                printf("Rotando la pila: %d (bit más bajo es 1)\n", *(current_a->number));
                ra(*stack_a);  // Rota la pila a la izquierda (ra)
                ft_lstiter(*stack_a, print_numbers); // Imprimimos el stack_a después de la operación ra
				has_even_bit = 1;
            }
			current_a = *stack_a;
            //current_a = current_a->next;  // Avanzamos al siguiente nodo
        }
    }

    printf("\nStack a (final):\n");
    ft_lstiter(*stack_a, print_numbers);

    printf("\nStack b (final):\n");
    ft_lstiter(*stack_b, print_numbers);
}

