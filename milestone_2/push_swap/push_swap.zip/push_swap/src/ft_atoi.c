/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 22:56:38 by frromero          #+#    #+#             */
/*   Updated: 2024/11/19 00:35:15 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

int ft_atoi(const char *str)
{
	int i;
	int s;
	int nb;

	i = 0;
	s = 1;
	nb = 0;
	while (str[i] != '\0')
	{
		while ((str[i] >= 9) && (str[i] <= 13 || str[i] == ' '))
			i++;
		if ((str[i] == '-' || str[i] == '+') && (str[i + 1] == '-' || str[i + 1] == '+'))
			return (0);
		else if (str[i] == '+')
			i++;
		else if (str[i] == '-')
		{
			s = -1;
			i++;
		}
		while (str[i] >= '0' && str[i] <= '9')
		{
			if (nb > INT_MAX / 10 || (nb == INT_MAX / 10 && (str[i] - '0') > INT_MAX % 10))
				program_error();
			nb = nb * 10 + str[i] - '0';
			// FALTA EL CONTROL DEL NUEMRO NEGATIVO MINIMO **********************

			i++;
		}
		return (nb * s);
	}
	return (0);
}
