/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 20:31:22 by frromero          #+#    #+#             */
/*   Updated: 2024/11/21 22:04:07 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"



int main(int argc, char **argv)
{
	t_list *lst = NULL;     // Puntero a la cabeza de la lista enlazada (inicialmente vacía)
	t_list *new_node = NULL; // Puntero temporal que apunta a un nuevo nodo durante su creación
	t_list *lstb = NULL;     // Puntero a la cabeza de la lista enlazada (inicialmente vacía)
	t_list *new_nodeb = NULL; // Puntero temporal que apunta a un nuevo nodo durante su creación
	//t_list	*last_node;
	//t_list	*mapped_lst;
	//t_list	*tmp;

	check_input(argc, argv);
	init_stack_a(argc, argv, new_node, &lst);
	init_stack_b(new_nodeb, &lstb);
	printf("\nPila a:\n");
	ft_lstiter(lst, print_numbers);

	pb(lst, lstb);
	printf("\nPila a:\n");
	ft_lstiter(lst, print_numbers);
	printf("\nPila b:\n");
	ft_lstiter(lstb, print_numbers);





	return (0);
}
