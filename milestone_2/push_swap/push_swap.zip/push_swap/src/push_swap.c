/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 20:31:22 by frromero          #+#    #+#             */
/*   Updated: 2024/11/19 00:12:01 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"



int main(int argc, char **argv)
{
	check_input(argc, argv);
	// cuando obtengamos los números de argv hay que chequear los limites del "int"
	return (0);
}
