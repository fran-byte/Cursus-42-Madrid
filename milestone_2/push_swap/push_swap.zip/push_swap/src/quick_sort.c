/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   quick_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/24 18:49:36 by frromero          #+#    #+#             */
/*   Updated: 2024/11/24 21:13:21 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void	quick_sort(t_list **stack_a, t_list **stack_b)
{
	t_list	*current_a;
	t_list	*current_b;

	current_a = *stack_a;
	current_b = *stack_b;
	if (*stack_a == NULL)
    	return;
	printf("Tamaño de stack_a: %d\n", ft_lstsize(*stack_a));
    printf("Primer elemento: %d\n", *current_a->number);
    printf("Segundo elemento: %d\n", *current_a->next->number);

	if (ft_lstsize(*stack_a) == 2 && current_a != NULL && current_a->next != NULL)
	{
		if((*current_a->number) > (*current_a->next->number))
			sa(*stack_a);
	}
	ft_lstiter(current_b, print_numbers); //BORRAR
	printf("\nStack a:\n");           //BORRAR
	ft_lstiter(current_a, print_numbers);//BORRAR
}
