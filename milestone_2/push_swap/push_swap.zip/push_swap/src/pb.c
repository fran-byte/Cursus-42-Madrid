/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pb.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/20 18:34:40 by frromero          #+#    #+#             */
/*   Updated: 2024/11/21 22:04:58 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* pb: Put the first element from stack a and places it on stack b.*/


// **** EN PRUEBAS AUN FALLANDO

#include "../inc/push_swap.h"

void del(void *content)
{
	free(content);
}

#include "../inc/push_swap.h"

void pb(t_list *lst, t_list *lstb)  // FUNCION EN PRUEBAS **** CON ERRORES ***
{
	t_list *stackb;
	t_list *tmp;
	int temp;

	if (!lst) // Si la lista está vacía, no hacemos nada
		return;

	stackb = lstb; // Apuntamos a la cabecera de stack B

	temp = *lst->number;	// Copiamos el valor (no la dirección) del primer nodo de A
	*stackb->number = temp; // Asignamos ese valor al primer nodo de B
	write(1, "pb\n", 3);

	tmp = lst->next;		// Copiamos en un ptr temporal la dirección del siguiente nodo de A
	ft_lstdelone(lst, del); // Eliminamos el nodo actual de A (** NO LO ESTÁ BORRANDO)
	lst = tmp;				// Actualizamos la cabecera de A
}
