/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 22:49:16 by frromero          #+#    #+#             */
/*   Updated: 2024/11/19 21:11:07 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include<unistd.h>
# include<stdlib.h>
# include<limits.h>

# include <stdio.h> // borrar
# include <string.h> // borrar

void program_error();
void program_exit();
int	ft_atoi(const char *str);
void check_input(int argc, char **argv);



#endif
