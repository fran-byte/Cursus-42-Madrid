/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_up_to_five.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/28 17:44:15 by frromero          #+#    #+#             */
/*   Updated: 2024/11/28 19:34:32 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

void sort_three(t_list *stack_a)
{
	if ((*stack_a->number)> (*stack_a->next->number) &&
		(*stack_a->next->number) > (*stack_a->next->next->number))
	{
		sa(stack_a);
		rra(stack_a);
	}
	if ((*stack_a->next->next->number) > (*stack_a->number) &&
		(*stack_a->number) > (*stack_a->next->number))
	{
		rra(stack_a);
		sa(stack_a);
		rra(stack_a);
	}
	else if ((*stack_a->next->number) > (*stack_a->next->next->number)
		&& (*stack_a->next->next->number) > (*stack_a->number))
	{
		rra(stack_a);
		sa(stack_a);
	}
	else if ((*stack_a->next->number) > (*stack_a->number) &&
		(*stack_a->number) > (*stack_a->next->next->number))
			rra(stack_a);
	else if ((*stack_a->number) > (*stack_a->next->next->number) &&
		(*stack_a->next->next->number) > (*stack_a->next->number))
			ra(stack_a);
	printf("\nSTACK - ORDENADO:\n");	 // No Push
	ft_lstiter(stack_a, print_numbers); // No Push
}

void sort_up_to_five(t_list **stack_a, t_list **stack_b)
{
	if (ft_lstsize(*stack_a) == 3)
		sort_three(*stack_a);
}
