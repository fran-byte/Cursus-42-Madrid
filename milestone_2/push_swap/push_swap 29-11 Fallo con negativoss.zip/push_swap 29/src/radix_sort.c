/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   radix_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/24 18:49:36 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 19:51:12 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/push_swap.h"

int max_bits(t_list *stack)
{
	int max;
	int bits;

	bits = 0;
	max = 0;
	while (stack)
	{
		if (*(stack->number) > max)
			max = *(stack->number);
		stack = stack->next;
	}
	while (max > 0)
	{
		max >>= 1;
		bits++;
	}
	return (bits);
}

void radix_sort_multiple(t_list **stack_a, t_list **stack_b)
{
	t_list *current_a = *stack_a;
	int bit = 0;
	int size;
	int mov_bit = 0;
	int ra_counter = 0;
	int original_size = ft_lstsize(*stack_a);
	int max_bits_limit = max_bits(*stack_a);
	int moves = 0;

	printf("\nStack A Inicial\n---\n");
	ft_lstiter(*stack_a, print_numbers);

	if (*stack_a == NULL)
		return;

	while (is_sorted(*stack_a) != 1 && mov_bit < max_bits_limit)
	{
		size = ft_lstsize(*stack_a);
		current_a = *stack_a;
		ra_counter = 0;

		while ((ra_counter < size) && ft_lstsize(*stack_a) > 0)
		{
			if ((((*(current_a->number)) >> mov_bit) & 1) == 0)
			{
				printf("\n(PB) Low Bit: [%d] of number: %d\n",(((*(current_a->number)) >> mov_bit) & 1), *(current_a->number));
				pb(stack_a, stack_b);
				moves++;
				bit = 0;
				size--;
			}
			else
			{
				printf("\n(RA) Low Bit: [%d] of number: %d\n",(((*(current_a->number)) >> mov_bit) & 1), *(current_a->number));
				ra(*stack_a);
				moves++;
				bit = 1;
				ra_counter++;
			}
			//size = ft_lstsize(current_a);
			current_a = *stack_a;
			//printf("\n** VARIABLES ** current bit  = %d\n		ra_counter   = %d\n		stack A size = %d\n		max_bits_limit = %d\n", bit, ra_counter, size, max_bits_limit);
		}

		while (*stack_b)
			{
			moves++;
			pa(stack_a, stack_b);
			}

		mov_bit++;
		printf("Stack A after the Bit Shift:\n---\n");
		ft_lstiter(*stack_a, print_numbers);
		printf("\n**  BITs SHIFT ** ( %d ) **\n", mov_bit);
	}

	//if (is_sorted(*stack_a) != 1)  // no deberiamos llamarlo de nuevo
	//	radix_sort_multiple(stack_a, stack_b);
	if (is_sorted(*stack_a) == 1)
	{
		printf("\nSTACK - ORDENADO en %d MOVIMIENTOS\n", moves);
		ft_lstiter(*stack_a, print_numbers);
		return;
	}
		printf("\nSIN EXITO %d MOVIMIENTOS\n", moves);
		ft_lstiter(*stack_a, print_numbers);
}

void radix_sort(t_list **stack_a, t_list **stack_b)
{
	if (is_sorted(*stack_a) == 1)
		return;
	if (ft_lstsize(*stack_a) == 2)
	{
		sa(*stack_a);
		return;
	}
	if (ft_lstsize(*stack_a) == 3)
	{
		sort_up_to_five(stack_a, stack_b);
		return;
	}
	radix_sort_multiple(stack_a, stack_b);
}
