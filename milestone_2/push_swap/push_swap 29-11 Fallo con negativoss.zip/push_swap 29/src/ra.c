/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ra.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 08:06:04 by frromero          #+#    #+#             */
/*   Updated: 2024/11/29 08:54:10 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* Rotation (ra) moves the value of the first node to the last position,
   and shifts all other nodes' values one step backward.*/

#include "../inc/push_swap.h"

void ra(t_list *stack_a)
{
	t_list *current_a;
	int temp_a;

	if (!stack_a || !stack_a->next)
		return;
	temp_a = *stack_a->number;
	current_a = stack_a;
	while (current_a->next != NULL)
	{
		*current_a->number = *current_a->next->number;
		current_a = current_a->next;
	}
	*current_a->number = temp_a;
	write(1, "ra\n", 3);
}
