/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frromero <frromero@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/14 18:22:21 by frromero          #+#    #+#             */
/*   Updated: 2024/12/14 19:09:45 by frromero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include"pipex.h"

void check_input(int argc, char **argv)
{
	if (argc < 5)
	{
		write(1, "\nParameter error", 17);
		write(1, "\nTry again, for example:", 24);
		write(1, "\n./pipex infile \"ls -l\" \"wc -l\" outfile\n", 44);
		program_exit();
	}
}

int open_file(char *ofile)
{
	int fd;

	fd = open(ofile, O_RDONLY);
	return (fd);
}

void	admin_argv(int argc, char **argv)
{
	int fd;

	fd = open_file(argv[1]);
}

int	main(int argc, char **argv)
{
	check_input(argc, argv);
	admin_argv(argc, argv);

	return (0);
}
